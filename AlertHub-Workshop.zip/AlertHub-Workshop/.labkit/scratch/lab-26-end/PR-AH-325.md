## Summary
Makes the nightly back-off test deterministic. The old test asserted `backoff(3) < 8500`, but `backoff(3)` is 8000 plus 0–999 ms of random jitter, so it failed whenever jitter was 500 ms or more: a 50% failure rate.

## Jira
AH-325

## Changes
- `backoff(n, random = Math.random)`: jitter source is injectable; default behaviour unchanged
- `tests/nightly/backoff.test.js`: exact values with `random = () => 0` (retries 1–4 and 9, capped at MAX_BACKOFF_MS), maximum-jitter case, and a 1000-iteration property test of the documented window

## How it was tested
- [x] `npm test` passes
- [x] New or changed behaviour has tests
- Before: nightly suite 20 runs = [paste your P/F string from Lab 25]
- After: nightly suite 20 runs = PPPPPPPPPPPPPPPPPPPP

## Risk and rollback
No runtime change: callers that pass no `random` behave exactly as before. Rollback: revert this commit.

## Reviewer checklist
- [x] No secrets or PII in code, logs or tests
- [x] Error paths handled
- [ ] Docs / CHANGELOG updated
