process.env.NODE_ENV = 'test';
const providers = require('../src/providers');
const scheduler = require('../src/scheduler/retryScheduler');
const store = require('../src/store/memoryStore');
const { createAlert } = require('../src/services/alertService');
let calls = 0;
providers.email.send = async () => { calls += 1; throw new Error('ETIMEDOUT'); };
const T0 = Date.parse('2026-09-16T12:00:00Z');
(async () => {
  const { alert } = createAlert({ customerId: 'C-1002', channel: 'email', type: 'transaction', message: 'x', sourceEventId: 'w1' }, T0);
  for (let t = T0; t <= T0 + 120_000; t += 1_000) await scheduler.tick(t);
  console.log({ providerCalls: calls, finalStatus: store.get(alert.id).status, attempts: store.get(alert.id).attempts });
})();
