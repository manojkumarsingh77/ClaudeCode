Update for Customer Care (SUP-4812):
- Customers are receiving the same SMS or push notification up to five times within about 30 seconds.
- Email is not affected.
- The upstream order system is not the cause: AlertHub already ignores repeated order events.
- The cause is in AlertHub: the SMS and push gateways confirm delivery with a code AlertHub wrongly treats as a failure, so it sends again.
- Engineering has reproduced it and is scheduling a fix (AH-318).
