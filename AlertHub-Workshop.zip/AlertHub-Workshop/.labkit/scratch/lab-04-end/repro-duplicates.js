// Reproduces SUP-4812: one alert per channel, scheduler run for 60 simulated seconds.
process.env.NODE_ENV = 'test';
const { createAlert } = require('../src/services/alertService');
const scheduler = require('../src/scheduler/retryScheduler');
const providers = require('../src/providers');

const T0 = Date.parse('2026-09-16T12:00:00Z'); // daytime for every seeded customer

(async () => {
  for (const channel of ['email', 'sms', 'push']) {
    createAlert({ customerId: 'C-1001', channel, type: 'transaction', message: 'Order shipped', sourceEventId: `evt-${channel}` }, T0);
  }
  for (let t = T0; t <= T0 + 60_000; t += 1_000) await scheduler.tick(t);
  const counts = providers._outbox.reduce((m, o) => ({ ...m, [o.channel]: (m[o.channel] || 0) + 1 }), {});
  console.log('Messages sent per channel for ONE alert each:', counts);
})();
