## Summary
Holds non-critical alerts during customer quiet hours (22:00–07:00 local) and releases them at 07:00.
Resolves SUP-4827 (marketing SMS delivered at 02:14 IST).

## Jira
AH-312 (implementation), AH-313 (documentation)

## Changes
- New pure module `src/services/quietHours.js` (`nextAllowedSendTime`, `isQuietTime`), time always injected
- Applied when an alert is created and when a retry is scheduled
- Existing test fixtures moved from timestamp 0 to 12:00 UTC (0 is inside quiet hours)
- README section, `docs/quiet-hours.md`, CHANGELOG entry

## How it was tested
- [x] `npm test` passes
- [x] New or changed behaviour has tests: boundaries 21:59, 22:00, 06:59, 07:00; cross-midnight; critical bypass; 02:14 IST ticket case
- Coverage: `src/services/quietHours.js` 100% statements and branches

## Risk and rollback
Alerts already queued at deploy time keep their old `nextAttemptAt`; only new alerts and new retries are held.
Rollback: revert the merge commit. Known limitation: fixed offsets ignore daylight saving time (AH-341).

## Reviewer checklist
- [x] No secrets or PII in code, logs or tests
- [x] Error paths handled
- [x] Docs / CHANGELOG updated
