#!/usr/bin/env bash
# Smoke-test every documented route and status code. Run while `npm start` is running.
B=${BASE_URL:-http://localhost:3000}
code() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
post() { code -X POST "$B/alerts" -H 'content-type: application/json' -d "$1"; }
ID="smoke-$(date +%s)"
echo "POST /alerts valid -> $(post '{"customerId":"C-1002","channel":"email","type":"transaction","message":"m","sourceEventId":"'$ID'"}')"
echo "POST /alerts duplicate -> $(post '{"customerId":"C-1002","channel":"email","type":"transaction","message":"m","sourceEventId":"'$ID'"}')"
echo "POST /alerts missing fields -> $(post '{"customerId":"C-1002"}')"
echo "POST /alerts unknown customer -> $(post '{"customerId":"C-9999","channel":"email","type":"transaction","message":"m","sourceEventId":"'$ID'-x"}')"
echo "POST /alerts channel fax -> $(post '{"customerId":"C-1002","channel":"fax","type":"transaction","message":"m","sourceEventId":"'$ID'-fax"}')"
echo "GET /alerts -> $(code "$B/alerts")"
FIRST=$(curl -s "$B/alerts" | sed -n 's/.*"id":"\(A-[0-9]*\)".*/\1/p' | head -1)
echo "GET /alerts/:id existing -> $(code "$B/alerts/$FIRST")"
echo "GET /alerts/:id missing -> $(code "$B/alerts/A-99999")"
echo "GET /health -> $(code "$B/health")"
echo "POST /internal/scheduler/tick -> $(code -X POST "$B/internal/scheduler/tick")"
