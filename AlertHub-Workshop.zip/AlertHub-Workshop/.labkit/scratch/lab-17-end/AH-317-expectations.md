1. 21:59 local: sent immediately.
2. 22:00 local: held until 07:00 local.
3. 06:59 local: held until 07:00 the same morning.
4. 07:00 local: sent immediately (end is exclusive).
5. 23:30 local: held across midnight to 07:00 next day.
6. Critical and security alerts: never held.
7. Negative offsets (C-1003, UTC-05:00) use local time correctly.
8. A retry that would land in quiet hours moves to 07:00.
9. An alert released at 07:00 is not held again.
10. No code path reads the wall clock inside quiet-hours logic.
