# AH-315 prompt comparison

| Criterion | Round A (vague) | Round B (structured) |
|---|---|---|
| Scope | [0-2] | [0-2] |
| Correctness | [0-2] | [0-2] |
| Tests | [0-2] | [0-2] |
| Reviewability | [0-2] | [0-2] |
| Back-and-forth | [0-2] | [0-2] |
| **Total** | **[__]/10** | **[__]/10** |

What made the difference:
- [explicit scope: "before jitter", "retries 1-3 unchanged"]
- [test instructions: assert ranges, never exact random values]
- [verification: run npm test and show git diff --stat]
