# AH-324 — my choices (recorded before seeing the answer key)

| # | Requirement | My choice | Agreed with key? | Why / what I learned |
|---|---|---|---|---|
| 1 | 12:00 UTC fixtures in every test | Instructions | Yes | Always-on rule for every test |
| 2 | Release notes from commits | Skill | Yes | Procedure with script and template, on demand |
| 3 | Independent diff review | Subagent | Yes | Needs a fresh context and read-only tools |
| 4 | Live incident data | MCP | Yes | Data outside the repository |
| 5 | Never commit while tests fail | Instructions | No → Hook + rule | Instructions ask; only a hook guarantees it |
| 6 | Map three areas at once | Subagents in parallel | Yes | Keeps exploration out of the main context |
| 7 | Rules only for src/providers/ | Folder CLAUDE.md | Yes | Loads only when working in that folder |
| 8 | Share with 12 repositories | Skill | No → Plugin | Plugins package skills, agents, hooks and MCP together |
| 9 | "Explain this regex" | Just a prompt | Yes | Nothing to build |
