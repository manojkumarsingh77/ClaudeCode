SUP-4812 resolved in AH-318.
Cause: AlertHub treated the SMS and push gateways' "accepted" reply (HTTP 202) as a failure and re-sent each message up to 5 times.
Affected: SMS and push alerts since the SMS and push channels went live. Email was never affected.
Change: any "accepted" reply now counts as delivered; a regression test proves each alert is sent once.
Ships: next AlertHub release (v2.4.0).
Suggested reply for refund requests: "We sent you duplicate messages because of a fault on our side, now fixed. We have refunded the extra SMS charges."
