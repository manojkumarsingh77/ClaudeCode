// SUP-4827 scenario: a marketing SMS and a security SMS created at 02:14 IST.
process.env.NODE_ENV = 'test';
const { createAlert } = require('../src/services/alertService');
const scheduler = require('../src/scheduler/retryScheduler');
const providers = require('../src/providers');

const at = Date.parse('2026-09-16T20:44:00Z'); // 02:14 IST on 17 Sep
const ist = (ms) => new Date(ms + 330 * 60_000).toISOString().slice(11, 16) + ' IST';

(async () => {
  for (const type of ['marketing', 'security']) {
    const { alert } = createAlert({ customerId: 'C-1001', channel: 'sms', type, message: type, sourceEventId: `demo-${type}` }, at);
    console.log(`${type.padEnd(9)} nextAttemptAt ${new Date(alert.nextAttemptAt).toISOString()} (${ist(alert.nextAttemptAt)})`);
  }
  await scheduler.tick(at);
  console.log('sent at 20:44 UTC:', providers._outbox.map((o) => o.alertId));
})();
