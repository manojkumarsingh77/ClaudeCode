# AlertHub

Customer notification service for Acme. Receives alert requests from upstream systems
and delivers them by email, SMS and push.

    npm install
    npm test
    npm start
