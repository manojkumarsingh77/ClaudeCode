# Lab 4 — Duplicate-Alert Support Ticket Investigation

### Jira ticket

| Field | Value |
|---|---|
| Key | **AH-304** |
| Type | Bug |
| Summary | Investigate SUP-4812: customers receive the same alert several times |
| Epic | AH-300 — Claude Code Enablement for Engineering |
| Priority | High |
| Story points | 3 |
| Labels | claude-code, investigation, support |
| Reporter | [Customer Care Manager] |
| Assignee | Workshop participant |


## How to run this lab (single workspace)

1. From the workspace root run `bash lab.sh start 4`. It puts `alerthub/` in the exact state this lab starts from (history, branches, files from earlier labs), installs dependencies, runs the tests and opens VS Code.
2. Work through the steps below in `alerthub/`. This scenario is also copied to `alerthub/LAB.md`.
3. When you finish, run `bash lab.sh check 4` to run the "Check you are done" commands.
4. To see or recover the reference result: `bash lab.sh solution 4`.

### Business requirement

Customer Care has logged 312 complaints in 7 days from customers who received the same SMS or push notification four or five times. Forty-one customers have asked for refunds of SMS charges. Care believes the upstream order system sends each webhook twice and has escalated to that team. Before anyone changes code or blames another team, Engineering must establish the actual root cause with evidence, reproduce it, and state which channels are affected. This lab is about what a good investigation looks like; the fix comes in Lab 18.

### Tasks to perform

1. Read the support ticket and list the hypotheses.
2. Run a read-only investigation in Plan mode that cites file and line for every claim.
3. Test the care team's hypothesis explicitly.
4. Reproduce the defect with a script in the `scratch/` folder.
5. Write a short investigation summary for Customer Care.

### Acceptance criteria

- [ ] The root cause is identified with file:line evidence (`src/scheduler/retryScheduler.js:21` treats only HTTP 200 as success).
- [ ] The "webhook sent twice" hypothesis is ruled out with evidence (`src/services/alertService.js:18`).
- [ ] A reproduction prints `{ email: 1, sms: 5, push: 5 }`.
- [ ] No file under `src/` or `tests/` is changed (`git status` shows only `scratch/`, which is ignored).

### Step-by-step activity

**Before you start**

| Work on branch | Start from | Time | You will produce |
|---|---|---|---|
| main | `bash lab.sh start 4` | 25 min | scratch/repro-duplicates.js and a Care update |

#### Step 1 — Read the ticket (Editor)

Open `docs/support/SUP-4812.md`. Note three facts: SMS and push only, "five times in about a minute", and the care team's webhook theory.

#### Step 2 — See what a weak prompt produces (Panel)

Start a **new conversation** and set the mode indicator to **Plan**.

**Prompt — type in the Claude Code panel:**

```text
Why are customers getting duplicate alerts?
```

> **Expected:** A plausible but unverified answer, often a list of possible causes. Notice what is missing: no evidence, no ruling out, no reproduction. This is what "not good enough" looks like.

#### Step 3 — Run a good investigation (Panel)

Start a **new conversation**, keep **Plan** mode, and type `@docs/support/SUP-4812.md` to attach the ticket.

**Prompt — type in the Claude Code panel:**

```text
@docs/support/SUP-4812.md Investigate this read-only. Do not edit files.
1. List the hypotheses, including the care team's "webhook sent twice" theory.
2. For each hypothesis, find evidence that confirms or rules it out. Cite every claim as file:line.
3. Identify the root cause and exactly which channels are affected and why.
4. Explain why the customer sees about five messages in under a minute, using the config values.
Keep the answer under 20 lines.
```

> **Expected:** Claude rules out the webhook theory because `src/services/alertService.js:18` already de-duplicates by `sourceEventId`. It identifies `src/scheduler/retryScheduler.js:21` (`if (res.status === 200)`) and `src/providers/index.js`, where SMS and push return `202 Accepted`. Each successful send is therefore treated as a failure and retried up to `MAX_ATTEMPTS = 5` (`src/config.js:4`), with back-off delays of about 2, 4, 8 and 16 seconds, so five sends arrive within roughly 30 seconds. Email (200) is unaffected.

#### Step 4 — Verify one claim yourself (Editor)

Open `src/scheduler/retryScheduler.js` and go to line 21. Open `src/providers/index.js`. Confirm the evidence with your own eyes. A good engineer never forwards a claim they have not checked.

#### Step 5 — Reproduce it (Panel)

Switch the mode indicator to **Manual** (Claude now needs to create one file).

**Prompt — type in the Claude Code panel:**

```text
Write scratch/repro-duplicates.js that creates one transaction alert per channel for customer C-1001 at 12:00 UTC on 2026-09-16, runs scheduler.tick every simulated second for 60 seconds, and prints how many messages each channel's provider sent. Use the provider _outbox. Set NODE_ENV=test first so the logger is silent. Do not change any file outside scratch/. Then run it with node.
```

> **Expected:** Claude creates the script (compare with `bash lab.sh solution 4`) and runs it. Output:

```text
Messages sent per channel for ONE alert each: { email: 1, sms: 5, push: 5 }
```

#### Step 6 — Confirm nothing else changed (Terminal)

```bash
git status --short
```

> **Expected:** No output. `scratch/` is in `.gitignore`, and no source or test file changed.

#### Step 7 — Write the summary for Customer Care (Panel)

**Prompt — type in the Claude Code panel:**

```text
Write a 5-line update for Customer Care about SUP-4812 in plain language: what is happening, which channels, that the upstream webhook is not the cause, the evidence, and that a fix is being scheduled. No code, no customer names or phone numbers.
```

> **Expected:** A short, non-technical update you could paste into the ticket. Save it to `scratch/SUP-4812-update.md` if you want to keep it.

### What good looks like — the investigation standard

|Weak investigation|Good investigation|
|---|---|
|Lists possible causes|Tests each hypothesis against the code|
|"It might be the retry logic"|"`retryScheduler.js:21` treats 202 as failure"|
|Accepts the reporter's theory|Rules the theory in or out with evidence|
|Proposes a fix immediately|Reproduces the defect first, then proposes|
|Unbounded scope|States the blast radius: SMS and push, not email|

### Check you are done (Terminal)

```bash
git status --short
node scratch/repro-duplicates.js
```

> **Expected:** No changed files, then `{ email: 1, sms: 5, push: 5 }`.

### Validation and troubleshooting

|Problem|Fix|
|---|---|
|Claude starts editing files|The mode indicator is not on **Plan**. Switch it, or say "read-only, do not edit".|
|Reproduction prints `{}` (only after Lab 12)|The alerts were created inside quiet hours. Use a daytime timestamp such as `Date.parse('2026-09-16T12:00:00Z')`.|
|Reproduction shows `sms: 1`|You are on a branch where the defect is already fixed. Run `git checkout main`.|
