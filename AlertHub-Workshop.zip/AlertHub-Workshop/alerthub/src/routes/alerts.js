const express = require('express');
const store = require('../store/memoryStore');
const { createAlert } = require('../services/alertService');

const router = express.Router();

router.post('/', (req, res) => {
  try {
    const { alert, duplicate } = createAlert(req.body);
    res.status(duplicate ? 200 : 201).json({ alert, duplicate });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

router.get('/', (req, res) => {
  const list = store.all().filter((a) => !req.query.customerId || a.customerId === req.query.customerId);
  res.json({ alerts: list });
});

router.get('/:id', (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: 'not found' });
  res.json({ alert: a });
});

module.exports = router;
