// Fake channel providers. Each records what it "sent" in an outbox for inspection.
// Real gateways: email API answers 200 OK; SMS and push gateways answer 202 Accepted (queued for delivery).
const outbox = [];
function provider(channel, okStatus) {
  return {
    async send(alert) {
      outbox.push({ channel, alertId: alert.id, to: alert.to, at: Date.now() });
      return { status: okStatus, providerRef: `${channel}-${outbox.length}` };
    },
  };
}
module.exports = {
  email: provider('email', 200),
  sms: provider('sms', 202),
  push: provider('push', 202),
  _outbox: outbox,
  _reset: () => { outbox.length = 0; },
};
