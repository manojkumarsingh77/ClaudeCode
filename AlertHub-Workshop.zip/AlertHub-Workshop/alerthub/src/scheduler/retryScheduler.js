const config = require('../config');
const providers = require('../providers');
const store = require('../store/memoryStore');
const log = require('../lib/logger');
const { withRetry } = require('../lib/withRetry');

function backoff(n) {
  const b = config.BASE_DELAY_MS * 2 ** (n - 1);
  return b + Math.floor(Math.random() * config.JITTER_MS);
}

async function attempt(a, now = Date.now()) {
  const p = providers[a.channel];
  a.attempts += 1;
  let res;
  try {
    res = await withRetry(() => p.send(a), config.TRANSPORT_RETRIES);
  } catch (e) {
    res = { status: 0, error: e.message };
  }
  if (res.status === 200) {
    a.status = 'delivered';
    a.deliveredAt = now;
  } else if (a.attempts >= config.MAX_ATTEMPTS) {
    a.status = 'failed';
  } else {
    a.status = 'retrying';
    a.nextAttemptAt = now + backoff(a.attempts);
  }
  store.save(a);
  log.info('delivery attempt', { alert: a, res });
  return a;
}

async function tick(now = Date.now()) {
  const due = store.all().filter((a) => ['queued', 'retrying'].includes(a.status) && a.nextAttemptAt <= now);
  for (const a of due) await attempt(a, now);
  return due.length;
}

function start(intervalMs = config.TICK_MS) {
  return setInterval(() => tick().catch((e) => log.error('tick failed', { error: e.message })), intervalMs);
}

module.exports = { tick, start, attempt, backoff };
