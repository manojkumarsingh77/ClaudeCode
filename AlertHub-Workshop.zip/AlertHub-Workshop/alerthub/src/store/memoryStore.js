const customers = new Map([
  ['C-1001', { id: 'C-1001', name: 'Priya Nair', phone: '+919820011122', email: 'priya@example.com', utcOffsetMinutes: 330 }],
  ['C-1002', { id: 'C-1002', name: 'James Carter', phone: '+447700900123', email: 'james@example.com', utcOffsetMinutes: 0 }],
  ['C-1003', { id: 'C-1003', name: 'Ana Souza', phone: '+15555550142', email: 'ana@example.com', utcOffsetMinutes: -300 }],
]);
const alerts = new Map();
let seq = 0;
module.exports = {
  getCustomer: (id) => customers.get(id),
  nextId: () => `A-${String(++seq).padStart(5, '0')}`,
  save: (a) => { alerts.set(a.id, a); return a; },
  get: (id) => alerts.get(id),
  all: () => [...alerts.values()],
  findBySourceEvent: (eventId) => [...alerts.values()].find((a) => a.sourceEventId === eventId),
  _reset: () => { alerts.clear(); seq = 0; },
};
