const express = require('express');
const alerts = require('./routes/alerts');
const store = require('./store/memoryStore');

const app = express();
app.use(express.json());
app.use('/alerts', alerts);
app.get('/health', (req, res) => {
  const all = store.all();
  res.json({
    status: 'ok',
    queued: all.filter((a) => a.status === 'queued').length,
    retrying: all.filter((a) => a.status === 'retrying').length,
  });
});
module.exports = app;
