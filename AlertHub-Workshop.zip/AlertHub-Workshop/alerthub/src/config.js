module.exports = {
  PORT: Number(process.env.PORT || 3000),
  TICK_MS: 1000,
  MAX_ATTEMPTS: 5,
  BASE_DELAY_MS: 2000,
  JITTER_MS: 1000,
  TRANSPORT_RETRIES: 2,
  SMS_API_KEY: process.env.SMS_API_KEY || 'ak_live_DEMO_4f9c2b7e1d',
};
