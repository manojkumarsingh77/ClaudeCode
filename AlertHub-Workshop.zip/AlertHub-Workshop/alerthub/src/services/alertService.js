const store = require('../store/memoryStore');

const CHANNELS = ['email', 'sms', 'push'];

function createAlert(input, now = Date.now()) {
  const { customerId, channel, type, message, sourceEventId } = input;
  if (!customerId || !channel || !type || !message || !sourceEventId) {
    const err = new Error('customerId, channel, type, message and sourceEventId are required');
    err.status = 400;
    throw err;
  }
  const customer = store.getCustomer(customerId);
  if (!customer) {
    const err = new Error(`unknown customer ${customerId}`);
    err.status = 404;
    throw err;
  }
  const existing = store.findBySourceEvent(sourceEventId);
  if (existing) return { alert: existing, duplicate: true };

  const alert = {
    id: store.nextId(),
    customerId,
    channel,
    type,
    priority: type === 'security' ? 'critical' : input.priority || 'normal',
    message,
    sourceEventId,
    to: channel === 'email' ? customer.email : customer.phone,
    status: 'queued',
    attempts: 0,
    createdAt: now,
    nextAttemptAt: now,
  };
  store.save(alert);
  return { alert, duplicate: false };
}

module.exports = { createAlert, CHANNELS };
