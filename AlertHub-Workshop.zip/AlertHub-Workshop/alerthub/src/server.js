const app = require('./app');
const config = require('./config');
const scheduler = require('./scheduler/retryScheduler');

app.post('/internal/scheduler/tick', async (req, res) => res.json({ processed: await scheduler.tick() }));
app.listen(config.PORT, () => console.log(`AlertHub listening on :${config.PORT}`));
scheduler.start();
