## Summary
<!-- What changed and why. Link the Jira ticket. -->

## Jira
AH-

## Changes
-

## How it was tested
- [ ] `npm test` passes
- [ ] New or changed behaviour has tests

## Risk and rollback
<!-- Blast radius, feature flags, how to revert -->

## Reviewer checklist
- [ ] No secrets or PII in code, logs or tests
- [ ] Error paths handled
- [ ] Docs / CHANGELOG updated
