// Fast suite: runs on every change. The nightly suite lives in tests/nightly/.
module.exports = { testEnvironment: 'node', testPathIgnorePatterns: ['/node_modules/', '/tests/nightly/'] };
