const app = require('../src/app');
const store = require('../src/store/memoryStore');

let server; let base;
beforeAll((done) => {
  server = app.listen(0, () => {
    base = `http://127.0.0.1:${server.address().port}`;
    done();
  });
});
afterAll((done) => {
  server.close(done);
});
beforeEach(() => store._reset());

const post = (body) => fetch(`${base}/alerts`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

test('POST /alerts creates an alert (201) and GET /alerts/:id returns it', async () => {
  const res = await post({ customerId: 'C-1001', channel: 'email', type: 'transaction', message: 'Receipt', sourceEventId: 'evt-10' });
  expect(res.status).toBe(201);
  const { alert } = await res.json();
  const got = await fetch(`${base}/alerts/${alert.id}`);
  expect(got.status).toBe(200);
});

test('POST /alerts returns 400 when fields are missing', async () => {
  const res = await post({ customerId: 'C-1001' });
  expect(res.status).toBe(400);
});

test('GET /health reports queue depth', async () => {
  await post({ customerId: 'C-1001', channel: 'sms', type: 'marketing', message: 'Hi', sourceEventId: 'evt-11' });
  const body = await (await fetch(`${base}/health`)).json();
  expect(body).toEqual({ status: 'ok', queued: 1, retrying: 0 });
});
