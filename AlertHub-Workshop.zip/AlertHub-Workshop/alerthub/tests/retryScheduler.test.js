const store = require('../src/store/memoryStore');
const providers = require('../src/providers');
const scheduler = require('../src/scheduler/retryScheduler');
const { createAlert } = require('../src/services/alertService');
const config = require('../src/config');

beforeEach(() => { store._reset(); providers._reset(); jest.restoreAllMocks(); });

const emailAlert = (id = 'evt-e') =>
  createAlert({ customerId: 'C-1002', channel: 'email', type: 'transaction', message: 'Receipt', sourceEventId: id }, 0).alert;

test('delivers an email alert on the first tick', async () => {
  const a = emailAlert();
  await scheduler.tick(0);
  expect(store.get(a.id).status).toBe('delivered');
  expect(providers._outbox).toHaveLength(1);
});

test('schedules a retry when the provider throws', async () => {
  jest.spyOn(providers.email, 'send').mockRejectedValue(new Error('ETIMEDOUT'));
  const a = emailAlert();
  await scheduler.tick(0);
  const saved = store.get(a.id);
  expect(saved.status).toBe('retrying');
  expect(saved.nextAttemptAt).toBeGreaterThanOrEqual(config.BASE_DELAY_MS);
});

test('marks the alert failed after MAX_ATTEMPTS', async () => {
  jest.spyOn(providers.email, 'send').mockRejectedValue(new Error('ETIMEDOUT'));
  const a = emailAlert();
  for (let i = 0; i < config.MAX_ATTEMPTS; i++) await scheduler.tick(i * 60_000);
  expect(store.get(a.id)).toMatchObject({ status: 'failed', attempts: config.MAX_ATTEMPTS });
});
