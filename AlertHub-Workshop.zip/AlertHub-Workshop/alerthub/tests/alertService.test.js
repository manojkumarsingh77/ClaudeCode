const store = require('../src/store/memoryStore');
const { createAlert } = require('../src/services/alertService');

beforeEach(() => store._reset());

test('creates a queued alert addressed to the customer', () => {
  const { alert, duplicate } = createAlert({
    customerId: 'C-1001', channel: 'sms', type: 'transaction', message: 'Order shipped', sourceEventId: 'evt-1',
  }, 1_000);
  expect(duplicate).toBe(false);
  expect(alert).toMatchObject({ status: 'queued', to: '+919820011122', nextAttemptAt: 1_000, priority: 'normal' });
});

test('returns the existing alert when the same source event is received twice', () => {
  const input = { customerId: 'C-1002', channel: 'email', type: 'marketing', message: 'Sale', sourceEventId: 'evt-2' };
  const first = createAlert(input).alert;
  const second = createAlert(input);
  expect(second.duplicate).toBe(true);
  expect(second.alert.id).toBe(first.id);
});

test('security alerts are always critical', () => {
  const { alert } = createAlert({ customerId: 'C-1003', channel: 'push', type: 'security', message: 'New login', sourceEventId: 'evt-3' });
  expect(alert.priority).toBe('critical');
});

test('rejects an unknown customer with 404', () => {
  expect(() => createAlert({ customerId: 'C-9', channel: 'sms', type: 'marketing', message: 'x', sourceEventId: 'e' }))
    .toThrow(expect.objectContaining({ status: 404 }));
});
