const { backoff } = require('../../src/scheduler/retryScheduler');

test('third retry waits about eight seconds', () => {
  expect(backoff(3)).toBeLessThan(8500);
});
