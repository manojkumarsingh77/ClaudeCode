module.exports = { testEnvironment: 'node', testMatch: ['<rootDir>/tests/nightly/**/*.test.js'] };
