#!/usr/bin/env bash
# AlertHub Workshop - one project for all 26 labs.
#
#   bash lab.sh list              list the labs and show which one is active
#   bash lab.sh start <N>         put the workspace in the exact state Lab N starts from
#   bash lab.sh solution <N>      jump to the reference end state of Lab N (commits, branches, scratch files)
#   bash lab.sh check <N>         run Lab N's "Check you are done" commands
#   bash lab.sh status            show the active lab, branch and test result
#
# start and solution discard uncommitted work in alerthub/ (they ask first; add -y to skip the question).
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
KIT="$ROOT/.labkit"
APP="$ROOT/alerthub"
cmd="${1:-list}"; N="${2:-}"; YES="${3:-}"

die() { echo "Error: $*" >&2; exit 1; }
nn() { printf '%02d' "$((10#$1))"; }
labfile() { ls "$ROOT"/labs/Lab-"$(nn "$1")"-*.md 2>/dev/null | head -1; }
need_n() { [[ "$N" =~ ^[0-9]+$ ]] && [ "$N" -ge 1 ] && [ "$N" -le 26 ] || die "give a lab number 1-26, e.g. bash lab.sh $cmd 12"; }
confirm() {
  [ "$YES" = "-y" ] && return 0
  read -r -p "$1 [y/N] " a; [ "$a" = "y" ] || [ "$a" = "Y" ] || { echo "Cancelled."; exit 1; }
}

install_deps() {
  ( cd "$APP" && npm install --no-audit --no-fund --loglevel=error )
  if [ -f "$APP/mcp-servers/incident-desk/package.json" ]; then
    ( cd "$APP/mcp-servers/incident-desk" && npm install --no-audit --no-fund --loglevel=error )
  fi
}

# set_state <state-name> <branch-to-check-out>
set_state() {
  local state="$1" branch="$2"
  [ -d "$APP/.git" ] || die "alerthub/ is missing. Run: bash lab.sh start 4 -y (or re-extract the zip)."
  cd "$APP"
  git reset -q --hard
  git clean -q -fdx -e node_modules -e LAB.md
  git fetch -q --no-tags "$KIT/vault.git" "+refs/states/$state/*:refs/labkit/*" "+refs/tags/v2.3.0:refs/tags/v2.3.0"
  git checkout -q --detach
  for b in $(git for-each-ref --format='%(refname:strip=2)' refs/heads); do
    git show-ref -q --verify "refs/labkit/$b" || git branch -q -D "$b"
  done
  for b in $(git for-each-ref --format='%(refname:strip=2)' refs/labkit); do
    git branch -f -q "$b" "refs/labkit/$b"
  done
  git checkout -q "$branch"
  git for-each-ref --format='%(refname)' refs/labkit | while read -r r; do git update-ref -d "$r"; done
  rm -rf scratch
  if [ -d "$KIT/scratch/$state" ]; then cp -R "$KIT/scratch/$state" scratch; fi
  cd "$ROOT"
}

start_branch() { local b; b=$(grep "^$(nn "$1") " "$KIT/start-branch.txt" | cut -d' ' -f2); echo "${b:-main}"; }
end_branch() { cat "$KIT/states/lab-$(nn "$1")-end.branch"; }

show_tests() { ( cd "$APP" && npx jest --silent 2>&1 | grep -E "^Tests:" || true ); }

case "$cmd" in
  list)
    cur=$(cat "$KIT/current" 2>/dev/null || echo "-")
    echo "Active lab: $cur"
    for f in "$ROOT"/labs/Lab-*.md; do
      t=$(head -1 "$f" | sed 's/^# //'); echo "  $t"
    done
    ;;
  start)
    need_n
    f=$(labfile "$N")
    case "$N" in
      1)
        bash "$ROOT/tools/healthcheck.sh" || true
        echo "$N" > "$KIT/current"; echo "Lab 1: continue with Step 7 in $f" ;;
      2)
        confirm "Reset sandbox/claude-sandbox to its first commit?"
        ( cd "$ROOT/sandbox/claude-sandbox" && git reset -q --hard "$(git rev-list --max-parents=0 HEAD)" && git clean -q -fd -e node_modules \
          && npm install --no-audit --no-fund --loglevel=error )
        cp "$f" "$ROOT/sandbox/claude-sandbox/LAB.md"
        echo "$N" > "$KIT/current"
        echo "Lab 2 ready: open sandbox/claude-sandbox in VS Code and start at Step 2 of $f"
        command -v code >/dev/null && code "$ROOT/sandbox/claude-sandbox" || true ;;
      3)
        confirm "Lab 3 recreates alerthub/ from the seed script. Delete the current alerthub/ folder?"
        rm -rf "$APP"
        ( cd "$ROOT" && bash tools/seed-alerthub.sh )
        printf 'LAB.md\n' >> "$APP/.git/info/exclude"
        cp "$f" "$APP/LAB.md"; echo "$N" > "$KIT/current"
        echo "Lab 3: alerthub/ has been seeded. Continue with Step 3 of $f"
        command -v code >/dev/null && code "$APP" || true ;;
      *)
        confirm "Put alerthub/ in the Lab $N start state and discard uncommitted changes?"
        set_state "lab-$(nn $((N - 1)))-end" "$(start_branch "$N")"
        cp "$f" "$APP/LAB.md"
        install_deps
        echo "$N" > "$KIT/current"
        echo "Lab $N ready on branch $(git -C "$APP" branch --show-current). $(show_tests)"
        echo "Scenario: $f (also alerthub/LAB.md)"
        command -v code >/dev/null && code "$APP" || true ;;
    esac
    ;;
  solution)
    need_n
    case "$N" in
      1) echo "Lab 1 has no code solution: the deliverable is your healthcheck-report.txt." ;;
      2) confirm "Apply the Lab 2 reference solution to sandbox/claude-sandbox?"
         ( cd "$ROOT/sandbox/claude-sandbox" && git reset -q --hard "$(git rev-list --max-parents=0 HEAD)" && git clean -q -fd -e node_modules -e LAB.md \
           && git apply "$KIT/solutions/lab-02.patch" && git add -A && git commit -q -m "feat: add slugify utility" && npx jest --silent 2>&1 | grep -E "^Tests:" ) ;;
      *) confirm "Reset alerthub/ to the Lab $N reference solution and discard uncommitted changes?"
         set_state "lab-$(nn "$N")-end" "$(end_branch "$N")"
         install_deps
         echo "Lab $N reference solution applied on $(git -C "$APP" branch --show-current). $(show_tests)"
         git -C "$APP" log --oneline -3 ;;
    esac
    ;;
  check)
    need_n
    f=$(labfile "$N")
    block=$(awk '/^### Check you are done/{f=1;next} f&&/^```bash/{c=1;next} c&&/^```/{exit} c{print}' "$f")
    expected=$(awk '/^### Check you are done/{f=1} f&&/^> \*\*Expected:\*\*/{sub(/^> \*\*Expected:\*\* /,""); print; exit}' "$f")
    dir="$APP"; [ "$N" = 1 ] && dir="$HOME/claude-workshop"; [ "$N" = 2 ] && dir="$ROOT/sandbox/claude-sandbox"
    echo "Running in $dir:"; echo "$block" | sed 's/^/  $ /'; echo "----"
    ( cd "$dir" && bash -c "$block" ) || true
    echo "----"; echo "Expected: $expected"
    ;;
  status)
    echo "Active lab: $(cat "$KIT/current" 2>/dev/null || echo none)"
    [ -d "$APP/.git" ] && echo "Branch: $(git -C "$APP" branch --show-current)  $(show_tests)"
    ;;
  *) sed -n '2,12p' "$0" ;;
esac
