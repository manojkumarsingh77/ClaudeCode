#!/usr/bin/env bash
# Claude Code workshop - environment health check (Lab 1, AH-301)
# Usage: bash healthcheck.sh      Exit code 0 = ready, 1 = something needs fixing.
fail=0
check() { # name, command, minimum major version (optional)
  local name="$1" cmd="$2" min="${3:-}" out major
  if ! out=$(eval "$cmd" 2>/dev/null | head -1) || [ -z "$out" ]; then
    printf '  [FAIL] %-14s not found\n' "$name"; fail=1; return
  fi
  if [ -n "$min" ]; then
    major=$(echo "$out" | grep -oE '[0-9]+' | head -1)
    if [ "${major:-0}" -lt "$min" ]; then
      printf '  [FAIL] %-14s %s (need %s+)\n' "$name" "$out" "$min"; fail=1; return
    fi
  fi
  printf '  [ OK ] %-14s %s\n' "$name" "$out"
}
echo "Claude Code workshop - health check"
check "Node.js"      "node -v | tr -d v" 20
check "npm"          "npm -v"
check "Git"          "git --version | awk '{print \$3}'" 2
check "VS Code CLI"  "code --version"
check "Claude Code"  "claude --version"
if code --list-extensions 2>/dev/null | grep -qi '^anthropic\.claude-code$'; then
  printf '  [ OK ] %-14s installed\n' "VS Code ext"
else
  printf '  [FAIL] %-14s run: code --install-extension anthropic.claude-code\n' "VS Code ext"; fail=1
fi
if git config user.name >/dev/null && git config user.email >/dev/null; then
  printf '  [ OK ] %-14s %s <%s>\n' "Git identity" "$(git config user.name)" "$(git config user.email)"
else
  printf '  [FAIL] %-14s run: git config --global user.name "Your Name" (and user.email)\n' "Git identity"; fail=1
fi
if curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://registry.npmjs.org/ | grep -q 200; then
  printf '  [ OK ] %-14s registry.npmjs.org reachable\n' "Network"
else
  printf '  [FAIL] %-14s cannot reach registry.npmjs.org (proxy?)\n' "Network"; fail=1
fi
echo
[ $fail -eq 0 ] && echo "RESULT: READY" || echo "RESULT: NOT READY - fix the [FAIL] lines above"
exit $fail
