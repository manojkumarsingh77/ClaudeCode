#!/usr/bin/env bash
# AlertHub course repository - seed script (Lab 3, AH-300)
set -euo pipefail
mkdir alerthub && cd alerthub
git init -q -b main
git config user.name  >/dev/null 2>&1 || git config user.name  "Workshop Participant"
git config user.email >/dev/null 2>&1 || git config user.email "participant@example.com"
npm init -y >/dev/null
npm pkg set name=alerthub version=2.3.0 description="Acme customer notification service"
npm pkg set scripts.start="node src/server.js"
npm pkg set scripts.test="jest"
npm pkg set scripts.test:nightly="jest --config jest.nightly.config.js"
npm install express@4 >/dev/null 2>&1
npm install -D jest@29 >/dev/null 2>&1
mkdir -p src/routes src/services src/scheduler src/providers src/store src/lib tests/nightly docs/support .github/workflows
cat > jest.config.js <<'EOF'
// Fast suite: runs on every change. The nightly suite lives in tests/nightly/.
module.exports = { testEnvironment: 'node', testPathIgnorePatterns: ['/node_modules/', '/tests/nightly/'] };
EOF
cat > jest.nightly.config.js <<'EOF'
module.exports = { testEnvironment: 'node', testMatch: ['<rootDir>/tests/nightly/**/*.test.js'] };
EOF
printf 'node_modules/\n.env\n.claude/settings.local.json\ncoverage/\nscratch/\n' > .gitignore

# ---------- commit 1: bootstrap ----------
cat > src/config.js <<'EOF'
module.exports = {
  PORT: Number(process.env.PORT || 3000),
  TICK_MS: 1000,
  MAX_ATTEMPTS: 5,
  BASE_DELAY_MS: 2000,
  JITTER_MS: 1000,
  TRANSPORT_RETRIES: 2,
  SMS_API_KEY: process.env.SMS_API_KEY || 'ak_live_DEMO_4f9c2b7e1d',
};
EOF

cat > src/lib/logger.js <<'EOF'
function write(level, msg, ctx) {
  if (process.env.NODE_ENV === 'test') return;
  console.log(`${new Date().toISOString()} ${level} ${msg} ${ctx ? JSON.stringify(ctx) : ''}`);
}
module.exports = {
  info: (msg, ctx) => write('INFO', msg, ctx),
  error: (msg, ctx) => write('ERROR', msg, ctx),
};
EOF

cat > src/store/memoryStore.js <<'EOF'
const customers = new Map([
  ['C-1001', { id: 'C-1001', name: 'Priya Nair', phone: '+919820011122', email: 'priya@example.com', utcOffsetMinutes: 330 }],
  ['C-1002', { id: 'C-1002', name: 'James Carter', phone: '+447700900123', email: 'james@example.com', utcOffsetMinutes: 0 }],
  ['C-1003', { id: 'C-1003', name: 'Ana Souza', phone: '+15555550142', email: 'ana@example.com', utcOffsetMinutes: -300 }],
]);
const alerts = new Map();
let seq = 0;
module.exports = {
  getCustomer: (id) => customers.get(id),
  nextId: () => `A-${String(++seq).padStart(5, '0')}`,
  save: (a) => { alerts.set(a.id, a); return a; },
  get: (id) => alerts.get(id),
  all: () => [...alerts.values()],
  findBySourceEvent: (eventId) => [...alerts.values()].find((a) => a.sourceEventId === eventId),
  _reset: () => { alerts.clear(); seq = 0; },
};
EOF

cat > src/app.js <<'EOF'
const express = require('express');
const app = express();
app.use(express.json());
app.get('/health', (req, res) => res.json({ status: 'ok' }));
module.exports = app;
EOF

cat > src/server.js <<'EOF'
const app = require('./app');
const config = require('./config');
app.listen(config.PORT, () => console.log(`AlertHub listening on :${config.PORT}`));
EOF

cat > README.md <<'EOF'
# AlertHub

Customer notification service for Acme. Receives alert requests from upstream systems
and delivers them by email, SMS and push.

    npm install
    npm test
    npm start
EOF
git add . && git commit -qm "chore(AH-100): bootstrap AlertHub service"

# ---------- commit 2: alerts API ----------
cat > src/services/alertService.js <<'EOF'
const store = require('../store/memoryStore');

const CHANNELS = ['email', 'sms', 'push'];

function createAlert(input, now = Date.now()) {
  const { customerId, channel, type, message, sourceEventId } = input;
  if (!customerId || !channel || !type || !message || !sourceEventId) {
    const err = new Error('customerId, channel, type, message and sourceEventId are required');
    err.status = 400;
    throw err;
  }
  const customer = store.getCustomer(customerId);
  if (!customer) {
    const err = new Error(`unknown customer ${customerId}`);
    err.status = 404;
    throw err;
  }
  const existing = store.findBySourceEvent(sourceEventId);
  if (existing) return { alert: existing, duplicate: true };

  const alert = {
    id: store.nextId(),
    customerId,
    channel,
    type,
    priority: type === 'security' ? 'critical' : input.priority || 'normal',
    message,
    sourceEventId,
    to: channel === 'email' ? customer.email : customer.phone,
    status: 'queued',
    attempts: 0,
    createdAt: now,
    nextAttemptAt: now,
  };
  store.save(alert);
  return { alert, duplicate: false };
}

module.exports = { createAlert, CHANNELS };
EOF

cat > src/routes/alerts.js <<'EOF'
const express = require('express');
const store = require('../store/memoryStore');
const { createAlert } = require('../services/alertService');

const router = express.Router();

router.post('/', (req, res) => {
  try {
    const { alert, duplicate } = createAlert(req.body);
    res.status(duplicate ? 200 : 201).json({ alert, duplicate });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

router.get('/', (req, res) => {
  const list = store.all().filter((a) => !req.query.customerId || a.customerId === req.query.customerId);
  res.json({ alerts: list });
});

router.get('/:id', (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: 'not found' });
  res.json({ alert: a });
});

module.exports = router;
EOF

cat > src/app.js <<'EOF'
const express = require('express');
const alerts = require('./routes/alerts');
const store = require('./store/memoryStore');

const app = express();
app.use(express.json());
app.use('/alerts', alerts);
app.get('/health', (req, res) => {
  const all = store.all();
  res.json({
    status: 'ok',
    queued: all.filter((a) => a.status === 'queued').length,
    retrying: all.filter((a) => a.status === 'retrying').length,
  });
});
module.exports = app;
EOF

cat > tests/alertService.test.js <<'EOF'
const store = require('../src/store/memoryStore');
const { createAlert } = require('../src/services/alertService');

beforeEach(() => store._reset());

test('creates a queued alert addressed to the customer', () => {
  const { alert, duplicate } = createAlert({
    customerId: 'C-1001', channel: 'sms', type: 'transaction', message: 'Order shipped', sourceEventId: 'evt-1',
  }, 1_000);
  expect(duplicate).toBe(false);
  expect(alert).toMatchObject({ status: 'queued', to: '+919820011122', nextAttemptAt: 1_000, priority: 'normal' });
});

test('returns the existing alert when the same source event is received twice', () => {
  const input = { customerId: 'C-1002', channel: 'email', type: 'marketing', message: 'Sale', sourceEventId: 'evt-2' };
  const first = createAlert(input).alert;
  const second = createAlert(input);
  expect(second.duplicate).toBe(true);
  expect(second.alert.id).toBe(first.id);
});

test('security alerts are always critical', () => {
  const { alert } = createAlert({ customerId: 'C-1003', channel: 'push', type: 'security', message: 'New login', sourceEventId: 'evt-3' });
  expect(alert.priority).toBe('critical');
});

test('rejects an unknown customer with 404', () => {
  expect(() => createAlert({ customerId: 'C-9', channel: 'sms', type: 'marketing', message: 'x', sourceEventId: 'e' }))
    .toThrow(expect.objectContaining({ status: 404 }));
});
EOF

cat > tests/api.test.js <<'EOF'
const app = require('../src/app');
const store = require('../src/store/memoryStore');

let server; let base;
beforeAll((done) => {
  server = app.listen(0, () => {
    base = `http://127.0.0.1:${server.address().port}`;
    done();
  });
});
afterAll((done) => {
  server.close(done);
});
beforeEach(() => store._reset());

const post = (body) => fetch(`${base}/alerts`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

test('POST /alerts creates an alert (201) and GET /alerts/:id returns it', async () => {
  const res = await post({ customerId: 'C-1001', channel: 'email', type: 'transaction', message: 'Receipt', sourceEventId: 'evt-10' });
  expect(res.status).toBe(201);
  const { alert } = await res.json();
  const got = await fetch(`${base}/alerts/${alert.id}`);
  expect(got.status).toBe(200);
});

test('POST /alerts returns 400 when fields are missing', async () => {
  const res = await post({ customerId: 'C-1001' });
  expect(res.status).toBe(400);
});

test('GET /health reports queue depth', async () => {
  await post({ customerId: 'C-1001', channel: 'sms', type: 'marketing', message: 'Hi', sourceEventId: 'evt-11' });
  const body = await (await fetch(`${base}/health`)).json();
  expect(body).toEqual({ status: 'ok', queued: 1, retrying: 0 });
});
EOF
git add . && git commit -qm "feat(AH-101): alerts REST API with source-event de-duplication"

# ---------- commit 3: delivery-and-retry scheduler (email only) ----------
cat > src/lib/withRetry.js <<'EOF'
// Transport-level retry: re-invokes fn when it throws (network errors, timeouts).
async function withRetry(fn, retries = 2) {
  let lastErr;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr;
}
module.exports = { withRetry };
EOF

cat > src/providers/index.js <<'EOF'
// Fake channel providers. Each records what it "sent" in an outbox for inspection.
const outbox = [];
function provider(channel, okStatus) {
  return {
    async send(alert) {
      outbox.push({ channel, alertId: alert.id, to: alert.to, at: Date.now() });
      return { status: okStatus, providerRef: `${channel}-${outbox.length}` };
    },
  };
}
module.exports = {
  email: provider('email', 200),
  _outbox: outbox,
  _reset: () => { outbox.length = 0; },
};
EOF

cat > src/scheduler/retryScheduler.js <<'EOF'
const config = require('../config');
const providers = require('../providers');
const store = require('../store/memoryStore');
const log = require('../lib/logger');
const { withRetry } = require('../lib/withRetry');

function backoff(n) {
  const b = config.BASE_DELAY_MS * 2 ** (n - 1);
  return b + Math.floor(Math.random() * config.JITTER_MS);
}

async function attempt(a, now = Date.now()) {
  const p = providers[a.channel];
  a.attempts += 1;
  let res;
  try {
    res = await withRetry(() => p.send(a), config.TRANSPORT_RETRIES);
  } catch (e) {
    res = { status: 0, error: e.message };
  }
  if (res.status === 200) {
    a.status = 'delivered';
    a.deliveredAt = now;
  } else if (a.attempts >= config.MAX_ATTEMPTS) {
    a.status = 'failed';
  } else {
    a.status = 'retrying';
    a.nextAttemptAt = now + backoff(a.attempts);
  }
  store.save(a);
  log.info('delivery attempt', { alert: a, res });
  return a;
}

async function tick(now = Date.now()) {
  const due = store.all().filter((a) => ['queued', 'retrying'].includes(a.status) && a.nextAttemptAt <= now);
  for (const a of due) await attempt(a, now);
  return due.length;
}

function start(intervalMs = config.TICK_MS) {
  return setInterval(() => tick().catch((e) => log.error('tick failed', { error: e.message })), intervalMs);
}

module.exports = { tick, start, attempt, backoff };
EOF

cat > src/server.js <<'EOF'
const app = require('./app');
const config = require('./config');
const scheduler = require('./scheduler/retryScheduler');

app.post('/internal/scheduler/tick', async (req, res) => res.json({ processed: await scheduler.tick() }));
app.listen(config.PORT, () => console.log(`AlertHub listening on :${config.PORT}`));
scheduler.start();
EOF

cat > tests/retryScheduler.test.js <<'EOF'
const store = require('../src/store/memoryStore');
const providers = require('../src/providers');
const scheduler = require('../src/scheduler/retryScheduler');
const { createAlert } = require('../src/services/alertService');
const config = require('../src/config');

beforeEach(() => { store._reset(); providers._reset(); jest.restoreAllMocks(); });

const emailAlert = (id = 'evt-e') =>
  createAlert({ customerId: 'C-1002', channel: 'email', type: 'transaction', message: 'Receipt', sourceEventId: id }, 0).alert;

test('delivers an email alert on the first tick', async () => {
  const a = emailAlert();
  await scheduler.tick(0);
  expect(store.get(a.id).status).toBe('delivered');
  expect(providers._outbox).toHaveLength(1);
});

test('schedules a retry when the provider throws', async () => {
  jest.spyOn(providers.email, 'send').mockRejectedValue(new Error('ETIMEDOUT'));
  const a = emailAlert();
  await scheduler.tick(0);
  const saved = store.get(a.id);
  expect(saved.status).toBe('retrying');
  expect(saved.nextAttemptAt).toBeGreaterThanOrEqual(config.BASE_DELAY_MS);
});

test('marks the alert failed after MAX_ATTEMPTS', async () => {
  jest.spyOn(providers.email, 'send').mockRejectedValue(new Error('ETIMEDOUT'));
  const a = emailAlert();
  for (let i = 0; i < config.MAX_ATTEMPTS; i++) await scheduler.tick(i * 60_000);
  expect(store.get(a.id)).toMatchObject({ status: 'failed', attempts: config.MAX_ATTEMPTS });
});
EOF
git add . && git commit -qm "feat(AH-114): delivery-and-retry scheduler with exponential backoff"

# ---------- commit 4: SMS and push channels ----------
cat > src/providers/index.js <<'EOF'
// Fake channel providers. Each records what it "sent" in an outbox for inspection.
// Real gateways: email API answers 200 OK; SMS and push gateways answer 202 Accepted (queued for delivery).
const outbox = [];
function provider(channel, okStatus) {
  return {
    async send(alert) {
      outbox.push({ channel, alertId: alert.id, to: alert.to, at: Date.now() });
      return { status: okStatus, providerRef: `${channel}-${outbox.length}` };
    },
  };
}
module.exports = {
  email: provider('email', 200),
  sms: provider('sms', 202),
  push: provider('push', 202),
  _outbox: outbox,
  _reset: () => { outbox.length = 0; },
};
EOF
git add . && git commit -qm "feat(AH-120): add SMS and push delivery channels"

# ---------- commit 5: nightly suite, CI, support tickets, PR template ----------
cat > tests/nightly/backoff.test.js <<'EOF'
const { backoff } = require('../../src/scheduler/retryScheduler');

test('third retry waits about eight seconds', () => {
  expect(backoff(3)).toBeLessThan(8500);
});
EOF

cat > .github/workflows/ci.yml <<'EOF'
name: ci
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npm test
      - run: npm run test:nightly
EOF

cat > .github/pull_request_template.md <<'EOF'
## Summary
<!-- What changed and why. Link the Jira ticket. -->

## Jira
AH-

## Changes
-

## How it was tested
- [ ] `npm test` passes
- [ ] New or changed behaviour has tests

## Risk and rollback
<!-- Blast radius, feature flags, how to revert -->

## Reviewer checklist
- [ ] No secrets or PII in code, logs or tests
- [ ] Error paths handled
- [ ] Docs / CHANGELOG updated
EOF

cat > docs/support/SUP-4812.md <<'EOF'
# SUP-4812 - Customers receiving the same alert several times

- Reported: 2026-09-14 by Customer Care (Tier 2)
- Priority: P2  |  Affected customers: 312 complaints in 7 days
- Channel(s) reported: SMS (majority), some push. No email complaints.

## Customer statements
- "I got the 'Your order has shipped' SMS five times in about a minute." (C-1001)
- "My phone buzzed four or five times for the same delivery update." (C-1003)

## Care team notes
- Started roughly when the SMS channel went live.
- Care suspects the upstream order system is sending the webhook twice.
- Refunds of SMS charges requested by 41 customers.
EOF

cat > docs/support/SUP-4827.md <<'EOF'
# SUP-4827 - Marketing alerts delivered in the middle of the night

- Reported: 2026-09-16 by Customer Care (Tier 1)
- Priority: P3  |  Regions: India (IST, UTC+05:30) and UK

## Customer statements
- "Your 'Weekend sale' SMS woke me at 2:14 AM." (C-1001, India)
- "Got a promo push notification at 3 AM." (C-1002, UK)

## Care team notes
- The campaign tool schedules sends in UTC and knows nothing about customer time zones.
- Customers ask for "do not disturb" hours.
- Fraud and security alerts must still arrive immediately, day or night.
EOF
git add . && git commit -qm "chore(AH-131): CI workflow, nightly backoff suite, support tickets, PR template"
git tag v2.3.0
echo "AlertHub seeded: $(git rev-list --count HEAD) commits, tag v2.3.0"
