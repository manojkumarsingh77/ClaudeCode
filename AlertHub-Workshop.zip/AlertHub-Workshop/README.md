# AlertHub Workshop — one project for all 26 labs

This single workspace runs every lab in the Claude Code in VS Code curriculum. One command puts the AlertHub
repository in the exact state a lab starts from, so labs can be run in order, repeated, or started anywhere.

## Requirements
VS Code with the Claude Code extension (signed in), Node.js 20+, Git, and on Windows **Git Bash** as the terminal.
Lab 26 also needs a GitHub account and the GitHub CLI (`gh`).

## Quick start
```bash
cd AlertHub-Workshop
bash lab.sh list          # all labs
bash lab.sh start 4       # prepare alerthub/ for Lab 4 and open it in VS Code
# ...work through labs/Lab-04-*.md in the Claude Code panel...
bash lab.sh check 4       # run the lab's "Check you are done" commands
bash lab.sh solution 4    # optional: jump to the reference end state
bash lab.sh start 5       # next lab (discards uncommitted changes; asks first)
```

Open **`alerthub/`** (not the workspace root) in VS Code for Labs 3–26, so Claude Code sees AlertHub's `CLAUDE.md`,
`.claude/` and `.mcp.json` at the root. Open `sandbox/claude-sandbox/` for Lab 2.

## What is in the workspace
| Path | Purpose |
|---|---|
| `lab.sh` | `list`, `start N`, `check N`, `solution N`, `status` |
| `labs/` | The 26 lab scenarios: Jira ticket, business requirement, tasks, acceptance criteria, steps, prompts, checks |
| `alerthub/` | The AlertHub repository (Git). Starts at the Lab 4 state; `lab.sh start N` moves it to any lab |
| `sandbox/claude-sandbox/` | Disposable repository for Lab 2 |
| `tools/` | `healthcheck.sh` (Lab 1) and `seed-alerthub.sh` (Lab 3) |
| `guide/` | The complete Word lab guide |
| `.labkit/` | Every lab's start and end state (Git refs and scratch files). Do not edit |

## Labs
| Lab | Scenario | Prepare |
|---|---|---|
| 1 | [Lab 1 — Claude Code Environment Setup & Health Check](labs/Lab-01-Claude-Code-Environment-Setup-and-Health-Check.md) | `bash lab.sh start 1` |
| 2 | [Lab 2 — First Successful Claude Code Sandbox Round-Trip](labs/Lab-02-First-Successful-Claude-Code-Sandbox-Round-Trip.md) | `bash lab.sh start 2` |
| 3 | [Lab 3 — Instructor-Guided Environment Confirmation](labs/Lab-03-Instructor-Guided-Environment-Confirmation.md) | `bash lab.sh start 3` |
| 4 | [Lab 4 — Duplicate-Alert Support Ticket Investigation](labs/Lab-04-Duplicate-Alert-Support-Ticket-Investigation.md) | `bash lab.sh start 4` |
| 5 | [Lab 5 — Codebase-Wide Reasoning on an Unfamiliar Service](labs/Lab-05-Codebase-Wide-Reasoning-on-an-Unfamiliar-Service.md) | `bash lab.sh start 5` |
| 6 | [Lab 6 — Locate and Explain Retry Logic Across the Codebase](labs/Lab-06-Locate-and-Explain-Retry-Logic-Across-the-Codebase.md) | `bash lab.sh start 6` |
| 7 | [Lab 7 — Repository Onboarding with Claude Code](labs/Lab-07-Repository-Onboarding-with-Claude-Code.md) | `bash lab.sh start 7` |
| 8 | [Lab 8 — Read-Only Repository Exploration and Architecture Mapping](labs/Lab-08-Read-Only-Repository-Exploration-and-Architecture-Mapping.md) | `bash lab.sh start 8` |
| 9 | [Lab 9 — Map the REST Layer and Delivery-and-Retry Scheduler](labs/Lab-09-Map-the-REST-Layer-and-Delivery-and-Retry-Scheduler.md) | `bash lab.sh start 9` |
| 10 | [Lab 10 — Apply the Complete Explore → Plan → Code → Commit Workflow](labs/Lab-10-Apply-the-Complete-Explore-to-Plan-to-Code-to-Commit-Workflow.md) | `bash lab.sh start 10` |
| 11 | [Lab 11 — Investigate the Overnight-Alerts Complaint](labs/Lab-11-Investigate-the-Overnight-Alerts-Complaint.md) | `bash lab.sh start 11` |
| 12 | [Lab 12 — Implement Quiet-Hours Capability](labs/Lab-12-Implement-Quiet-Hours-Capability.md) | `bash lab.sh start 12` |
| 13 | [Lab 13 — Test, Review, Document, and Prepare a Clean Pull Request](labs/Lab-13-Test-Review-Document-and-Prepare-a-Clean-Pull-Request.md) | `bash lab.sh start 13` |
| 14 | [Lab 14 — Investigate the Under-Documented Delivery-and-Retry Scheduler](labs/Lab-14-Investigate-the-Under-Documented-Delivery-and-Retry-Scheduler.md) | `bash lab.sh start 14` |
| 15 | [Lab 15 — Compare Vague vs. Structured Engineering Prompts](labs/Lab-15-Compare-Vague-vs-Structured-Engineering-Prompts.md) | `bash lab.sh start 15` |
| 16 | [Lab 16 — Build a Reusable Engineering Prompt Library](labs/Lab-16-Build-a-Reusable-Engineering-Prompt-Library.md) | `bash lab.sh start 16` |
| 17 | [Lab 17 — Verification-First Review of the Quiet-Hours Change](labs/Lab-17-Verification-First-Review-of-the-Quiet-Hours-Change.md) | `bash lab.sh start 17` |
| 18 | [Lab 18 — Investigate the Duplicate-Alert Defect and Blast Radius](labs/Lab-18-Investigate-the-Duplicate-Alert-Defect-and-Blast-Radius.md) | `bash lab.sh start 18` |
| 19 | [Lab 19 — Security, Testing, Human Review Gates & PR Readiness](labs/Lab-19-Security-Testing-Human-Review-Gates-and-PR-Readiness.md) | `bash lab.sh start 19` |
| 20 | [Lab 20 — Create and Apply Claude Code Instructions](labs/Lab-20-Create-and-Apply-Claude-Code-Instructions.md) | `bash lab.sh start 20` |
| 21 | [Lab 21 — Build a Reusable Skill](labs/Lab-21-Build-a-Reusable-Skill.md) | `bash lab.sh start 21` |
| 22 | [Lab 22 — Task Decomposition Using Subagents](labs/Lab-22-Task-Decomposition-Using-Subagents.md) | `bash lab.sh start 22` |
| 23 | [Lab 23 — MCP Integration and Tool-Use Guardrails](labs/Lab-23-MCP-Integration-and-Tool-Use-Guardrails.md) | `bash lab.sh start 23` |
| 24 | [Lab 24 — Select Between Instructions, Skills, Subagents & MCP](labs/Lab-24-Select-Between-Instructions-Skills-Subagents-and-MCP.md) | `bash lab.sh start 24` |
| 25 | [Lab 25 — Investigate and Fix the Flaky Scheduler Test](labs/Lab-25-Investigate-and-Fix-the-Flaky-Scheduler-Test.md) | `bash lab.sh start 25` |
| 26 | [Lab 26 — Use the Connected GitHub Workflow to Prepare a Pull Request](labs/Lab-26-Use-the-Connected-GitHub-Workflow-to-Prepare-a-Pull-Request.md) | `bash lab.sh start 26` |

## Notes
- `start` and `solution` reset `alerthub/` and discard uncommitted work there. Commit or stash first; add `-y` to skip the question.
- Your commits are kept until you run `start` or `solution` again; the reference states are stored separately in `.labkit/`.
- Lab 3 deletes and re-seeds `alerthub/`; afterwards `bash lab.sh start 4` restores the course history.
