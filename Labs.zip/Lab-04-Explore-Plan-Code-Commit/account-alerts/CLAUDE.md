# Account-Alerts project instructions

## Project boundary
This is a local training repository. Never use real customer data or secrets. Do not deploy to external systems.

## Engineering conventions
- Node.js 22+ and Express 5.
- Use the built-in `node:test` runner.
- Prefer small, reviewable changes.
- Preserve existing API behavior unless the ticket explicitly requires a change.
- Do not add dependencies unless the ticket and review process explicitly allow it.
- Run tests and lint before presenting a change as complete.
- Never modify the seeded flaky test for an unrelated ticket.

## AI collaboration
- Read before editing.
- State assumptions and cite evidence when asked.
- Never invent file paths or line numbers.
- Keep a human review gate before commit/merge.
