# Lab 4 starter — Explore → Plan → Code → Commit

## Ticket
QH-101 — Quiet hours for non-critical account alerts.

## Starting state
This copy already contains the Lab 3 onboarding baseline (`CLAUDE.md` and `.claude/settings.json`) so participants can begin the Lab 4 workflow immediately.

## Requirement summary
1. Non-critical `info` and `warning` alerts are not sent during 22:00–07:00 in customer local time.
2. Held alerts are delivered when the window ends; they are never dropped.
3. Use the alert timezone; otherwise `defaultTimezone`.
4. `critical` alerts are sent immediately.
5. Configuration: `quietHours.enabled`, `start`, `end`; defaults enabled, 22:00, 07:00.
6. Start is inclusive; end is exclusive; windows may cross midnight.
7. A held alert keeps status and attempt count; `nextAttemptAt` becomes the exact end of the window in ISO-8601 UTC.
8. Retries due inside the window are held the same way.
9. No new dependencies.
10. Update tests and README. Do not modify `test/scheduler.retry.test.js`.

## Participant deliverable
A reviewable `feature/quiet-hours` branch with the four workflow stages, tests, documentation, and the draft PR evidence required by the lab.

## Acceptance evidence
The instructor acceptance suite `quiet-hours.acceptance.test.js` is intentionally outside the participant project. It is handed out/used at the lab checkpoint.
