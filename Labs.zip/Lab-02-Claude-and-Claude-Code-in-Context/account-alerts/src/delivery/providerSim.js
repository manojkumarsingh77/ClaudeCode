'use strict';
class ProviderSim {
  constructor({failFirstCalls=0, ackLossFirstCalls=0}={}) {
    this.failFirstCalls=failFirstCalls; this.ackLossFirstCalls=ackLossFirstCalls;
    this.calls=0; this.delivered=[]; this.keys=new Set();
  }
  async send({channel,to,body,idempotencyKey}) {
    this.calls += 1;
    if (this.failFirstCalls > 0) { this.failFirstCalls -= 1; throw new Error('provider unavailable'); }
    const duplicate = idempotencyKey && this.keys.has(idempotencyKey);
    if (!duplicate) {
      this.delivered.push({channel,to,body,idempotencyKey:idempotencyKey || null, call:this.calls});
      if (idempotencyKey) this.keys.add(idempotencyKey);
    }
    if (this.ackLossFirstCalls > 0) { this.ackLossFirstCalls -= 1; throw new Error('acknowledgement timeout'); }
    return {accepted:true, duplicate};
  }
}
module.exports={ProviderSim};
