'use strict';
const express = require('express');
const { ValidationError } = require('./services/alertService');
const alertsRouter = require('./routes/alerts');

function createApp(alertService) {
  const app = express();
  app.use(express.json());
  app.get('/health', (_req, res) => res.json({status: 'ok'}));
  app.use(alertsRouter(alertService));
  app.use((err, _req, res, _next) => {
    if (err instanceof ValidationError) return res.status(400).json({error: err.message, details: err.details});
    console.error(err);
    res.status(500).json({error: 'internal_error'});
  });
  return app;
}
module.exports = {createApp};
