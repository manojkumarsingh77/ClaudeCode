'use strict';
class Clock {
  now() { return new Date(); }
}
class FakeClock {
  constructor(start='2026-09-21T12:00:00.000Z') { this.current=new Date(start); }
  now() { return new Date(this.current); }
  advance(ms) { this.current=new Date(this.current.getTime()+ms); }
}
module.exports={Clock,FakeClock};
