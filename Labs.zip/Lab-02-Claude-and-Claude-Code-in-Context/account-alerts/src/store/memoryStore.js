'use strict';
class MemoryStore {
  constructor() { this.items=new Map(); }
  save(alert) { this.items.set(alert.id, {...alert}); return {...alert}; }
  get(id) { const a=this.items.get(id); return a ? {...a} : null; }
  list() { return [...this.items.values()].map(a=>({...a})); }
  listDue(now) { const t=now.getTime(); return this.list().filter(a=>a.status==='pending' && new Date(a.nextAttemptAt).getTime() <= t); }
}
module.exports={MemoryStore};
