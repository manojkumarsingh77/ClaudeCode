'use strict';
function nextDelayMs(attempt, policy, random=Math.random) {
  const raw = policy.baseDelayMs * Math.pow(policy.factor, attempt - 1);
  const jitter = (random() * 2 - 1) * policy.jitter;
  return Math.min(policy.maxDelayMs, Math.round(raw * (1 + jitter)));
}
module.exports={nextDelayMs};
