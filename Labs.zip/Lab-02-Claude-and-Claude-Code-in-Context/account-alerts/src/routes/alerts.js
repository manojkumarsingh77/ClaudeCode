'use strict';
const express = require('express');
const {ValidationError} = require('../services/alertService');

module.exports = function alertsRouter(alertService) {
  const router = express.Router();
  router.post('/v1/alerts', (req, res) => {
    try {
      const alert = alertService.create(req.body);
      res.status(201).json(alert);
    } catch (err) {
      if (err instanceof ValidationError) return res.status(400).json({error: err.message, details: err.details});
      throw err;
    }
  });
  router.get('/v1/alerts', (_req, res) => res.json(alertService.list()));
  router.get('/v1/alerts/:id', (req, res) => {
    const alert = alertService.get(req.params.id);
    if (!alert) return res.status(404).json({error:'not_found'});
    res.json(alert);
  });
  return router;
};
