'use strict';
module.exports = (req, res) => res.json({status:'ok'});
