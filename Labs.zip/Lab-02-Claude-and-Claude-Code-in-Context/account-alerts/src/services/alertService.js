'use strict';
const crypto = require('node:crypto');
class ValidationError extends Error {
  constructor(message, details=[]) { super(message); this.name='ValidationError'; this.details=details; }
}
class AlertService {
  constructor(store, clock, config) { this.store=store; this.clock=clock; this.config=config; }
  create(input={}) {
    const details=[];
    if (!input.accountId) details.push('accountId is required');
    if (!input.to) details.push('to is required');
    if (!input.message) details.push('message is required');
    if (details.length) throw new ValidationError('invalid alert', details);
    const now=this.clock.now().toISOString();
    const alert={
      id: crypto.randomUUID(), accountId:String(input.accountId), to:String(input.to),
      channel:input.channel || 'email', message:String(input.message), severity:input.severity || 'info',
      timezone:input.timezone || null, status:'pending', attempts:0, createdAt:now, nextAttemptAt:now
    };
    this.store.save(alert); return {...alert};
  }
  get(id) { const a=this.store.get(id); return a ? {...a} : null; }
  list() { return this.store.list().map(a=>({...a})); }
}
module.exports={AlertService,ValidationError};
