# Account-Alerts Service

A deliberately small Node.js 22 + Express 5 service used in the Claude Code for Product Engineers labs.

## Safety boundary
- Local training application only.
- The delivery provider is simulated; no real email/SMS is sent.
- Do not put real customer data, credentials, tokens, or secrets in this repository.

## Run
```bash
npm ci
npm test
npm run lint
npm start
```

## API
| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/v1/alerts` | Create an alert |
| GET | `/v1/alerts` | List alerts |
| GET | `/v1/alerts/:id` | Get one alert |

## Delivery model
The in-memory store holds alerts. The scheduler periodically finds due alerts and asks a simulated provider to deliver them. Failed deliveries use exponential backoff with jitter and eventually become `dead` after the configured maximum attempts.

## Training defects intentionally present
- `test/scheduler.retry.test.js` contains a deliberately flaky timing assertion (KI-1). Do not fix it until Lab 7.
- The scheduler does not yet pass an idempotency key to the provider, so SUP-4417 (duplicate delivery after an acknowledgement loss) remains for Lab 8.
- Quiet hours are not implemented on the baseline; QH-101 is the Lab 4 feature.

## Repository exploration hint
Start with `src/services/alertService.js`, `src/store/memoryStore.js`, `src/scheduler/deliveryScheduler.js`, `src/scheduler/retryPolicy.js`, and `config/default.json`.
