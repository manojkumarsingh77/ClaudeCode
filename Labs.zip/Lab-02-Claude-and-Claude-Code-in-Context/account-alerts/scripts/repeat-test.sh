#!/usr/bin/env bash
set -u
RUNS="${1:-20}"; FILE="${2:-test/scheduler.retry.test.js}"
fails=0
for ((i=1;i<=RUNS;i++)); do
  if node --test "$FILE" >/tmp/account-alerts-test.out 2>&1; then :; else fails=$((fails+1)); fi
done
echo "runs=$RUNS failures=$fails file=$FILE"
test "$fails" -eq 0
