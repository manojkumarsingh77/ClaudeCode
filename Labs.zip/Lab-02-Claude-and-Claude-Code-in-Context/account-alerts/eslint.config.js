const eslint = require('@eslint/js');
module.exports = [eslint.configs.recommended, {ignores: ['coverage/**','node_modules/**']}];
