# Lab 2 starter — Claude & Claude Code in Context

## Goal
Use an unfamiliar repository to build a mental model, locate retry logic, verify claims, compare tool choices, and observe collaborator-not-autopilot controls.

## Starting state
Baseline `account-alerts` repository. No application code should be changed for the exploration activities.

## Suggested first prompt
> What does this service do, and where does the retry logic live? Cite file paths and line numbers for every claim. Do not modify anything.

## Expected exploration targets
- `src/app.js` and `src/routes/alerts.js` — REST surface
- `src/services/alertService.js` — alert creation/validation
- `src/scheduler/deliveryScheduler.js` — scheduler tick and retry handling
- `src/scheduler/retryPolicy.js` — delay calculation
- `config/default.json` — retry limits and timing
- `test/` — evidence and coverage of behavior

## Participant deliverable
Create `notes/module2-tool-choice.md` during the lab and record claim verification plus the tool-choice decision. The notes folder is intentionally ignored by Git in this starter.
