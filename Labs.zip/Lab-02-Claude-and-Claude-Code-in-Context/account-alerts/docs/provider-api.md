# Simulated Provider API

`providerSim.js` models an external delivery provider. It accepts an object containing `channel`, `to`, `body`, and optionally `idempotencyKey`.

## Delivery semantics
- Without an idempotency key, each successful call is treated as a new delivery.
- With an idempotency key, repeated calls with the same key are treated as the same logical delivery.
- `ackLossFirstCalls` simulates a provider that records delivery but loses the acknowledgement. The caller sees an error and may retry.
- `failFirstCalls` simulates an ordinary provider failure without recording a delivery.

This is a local simulation; there are no external network calls.
