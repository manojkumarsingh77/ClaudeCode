'use strict';
const {MemoryStore}=require('../src/store/memoryStore');
const {FakeClock}=require('../src/utils/clock');
const {ProviderSim}=require('../src/delivery/providerSim');
const {AlertService}=require('../src/services/alertService');
const {DeliveryScheduler}=require('../src/scheduler/deliveryScheduler');
const baseConfig=()=>({defaultTimezone:'UTC',scheduler:{intervalMs:5000},retry:{maxAttempts:4,baseDelayMs:30000,factor:2,jitter:0.2,maxDelayMs:600000}});
const sample=(overrides={})=>({accountId:'A100',to:'user@example.com',channel:'email',message:'Account alert',severity:'info',...overrides});
function build({start='2026-09-21T12:00:00.000Z',faults={},config=baseConfig(),random=Math.random}={}) {
  const clock=new FakeClock(start), store=new MemoryStore(), provider=new ProviderSim(faults);
  const alertService=new AlertService(store,clock,config);
  const scheduler=new DeliveryScheduler({store,provider,clock,config,random});
  return {clock,store,provider,alertService,scheduler,config};
}
module.exports={baseConfig,sample,build};
