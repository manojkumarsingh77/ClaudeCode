'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const {createApp}=require('../src/app'); const {build,sample}=require('./helpers');
test('POST /v1/alerts creates an alert', async()=>{
  const {alertService}=build(); const app=createApp(alertService); const server=app.listen(0); const port=server.address().port;
  try { const r=await fetch(`http://127.0.0.1:${port}/v1/alerts`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(sample())}); assert.equal(r.status,201); assert.equal((await r.json()).status,'pending'); }
  finally {server.close();}
});
test('POST validates required fields', async()=>{ const {alertService}=build(); const app=createApp(alertService); const server=app.listen(0); const port=server.address().port; try { const r=await fetch(`http://127.0.0.1:${port}/v1/alerts`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'}); assert.equal(r.status,400); } finally {server.close();} });
test('GET /v1/alerts returns alerts', async()=>{ const {alertService}=build(); alertService.create(sample()); const app=createApp(alertService); const server=app.listen(0); const port=server.address().port; try { const r=await fetch(`http://127.0.0.1:${port}/v1/alerts`); assert.equal(r.status,200); assert.equal((await r.json()).length,1); } finally {server.close();} });
test('GET /v1/alerts/:id returns 404 for unknown id', async()=>{ const {alertService}=build(); const app=createApp(alertService); const server=app.listen(0); const port=server.address().port; try { const r=await fetch(`http://127.0.0.1:${port}/v1/alerts/nope`); assert.equal(r.status,404); } finally {server.close();} });
