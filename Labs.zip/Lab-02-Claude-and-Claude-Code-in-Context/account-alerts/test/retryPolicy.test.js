'use strict'; const test=require('node:test'); const assert=require('node:assert/strict'); const {nextDelayMs}=require('../src/scheduler/retryPolicy');
const p={baseDelayMs:30000,factor:2,jitter:0.2,maxDelayMs:600000};
test('attempt 1 with neutral jitter is 30s',()=>assert.equal(nextDelayMs(1,p,()=>0.5),30000));
test('attempt 2 with neutral jitter is 60s',()=>assert.equal(nextDelayMs(2,p,()=>0.5),60000));
test('attempt 3 with neutral jitter is 120s',()=>assert.equal(nextDelayMs(3,p,()=>0.5),120000));
test('delay is capped',()=>assert.equal(nextDelayMs(20,p,()=>0.5),600000));
