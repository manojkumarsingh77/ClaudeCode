'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const {build,sample}=require('./helpers'); const {nextDelayMs}=require('../src/scheduler/retryPolicy');
test('retry delay stays in the configured jitter band',async()=>{
  const c=build({faults:{failFirstCalls:1}}); c.alertService.create(sample()); await c.scheduler.tick();
  const actual=new Date(c.store.list()[0].nextAttemptAt).getTime()-c.clock.now().getTime();
  // KI-1: deliberately narrow assertion against a 20% jitter policy. It fails intermittently.
  assert.ok(actual >= 29000 && actual <= 31000, `delay ${actual}ms`);
});
test('retry delay formula can be deterministic when random is neutralised',()=>{
  const p={baseDelayMs:30000,factor:2,jitter:0.2,maxDelayMs:600000}; assert.equal(nextDelayMs(1,p,()=>0.5),30000);
});
