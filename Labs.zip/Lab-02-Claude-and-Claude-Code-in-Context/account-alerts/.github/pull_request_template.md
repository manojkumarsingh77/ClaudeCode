## Summary
<!-- What changed and why? -->

## Ticket
<!-- e.g. QH-101 -->

## What AI did
<!-- List generated/edited files, tests, prompts/skills/subagents used. -->

## What a human validated
<!-- Do not leave blank. State exactly what you personally verified. -->

## Verification
- [ ] npm test
- [ ] npm run lint
- [ ] coverage / targeted evidence where required
- [ ] no secrets or unintended dependency changes

## Risks / follow-up
<!-- Known limitations, pre-existing defects, escalations. -->
