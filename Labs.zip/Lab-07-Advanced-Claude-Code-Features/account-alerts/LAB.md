# Lab 7 starter — Advanced Claude Code Features

## Goal
Use the extension ladder: Instructions → Skills/Subagents → MCP and Plugins. Investigate KI-1, make the retry test deterministic, close the scheduler coverage gap, and prepare a reviewable PR.

## Starting state
Baseline application behavior with Lab 3 onboarding present. QH-101 is not included because Lab 7 branches from `main`.

## Known issue
`test/scheduler.retry.test.js` is intentionally flaky because it uses a narrow timing assertion against a jittered retry policy. The learner must reproduce and diagnose it before fixing it.

## Expected implementation direction
A deterministic test should neutralize randomness rather than weaken the production retry policy. The lab also asks for evidence around dead-after-maxAttempts, dead alerts not being retried, overlapping ticks, and scheduler coverage.

## Advanced artifacts participants create
- `.claude/skills/flaky-test-triage/SKILL.md`
- `.claude/agents/flake-repro-runner.md`
- a PR workflow skill as directed by the lab
- governance record under `notes/`
- GitHub plugin/MCP configuration only within the permitted local/project scope

## Credential rule
Never commit a GitHub token. Clean environment variables and shell history according to the lab instructions.
