# My Two-Week Claude Code Adoption Plan

Name: __________________________
Start date: ____________________
Day-14 review date: ____________

## Production ticket I will apply this to
Ticket / issue: ______________________________
Why this ticket is suitable: __________________

## My Explore → Plan → Code → Commit workflow
- Explore: ____________________________________
- Plan: _______________________________________
- Code: _______________________________________
- Commit: _____________________________________

## Definition of done
1. ____________________________________________
2. ____________________________________________
3. ____________________________________________

## Habit most likely to be lost
_______________________________________________

## Habit protector
Person / calendar / checklist / CI gate: __________

## Verification commitment
What evidence will I require before review? ________

## Day-14 retrospective
### Plan vs actual
________________________________________________
________________________________________________

### What I will keep
________________________________________________

### What I will change
________________________________________________
