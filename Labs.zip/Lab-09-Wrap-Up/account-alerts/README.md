# Lab 9 starter — Wrap-Up & Next Steps

Lab 9 does not require a new application change. Use this small workspace to convert the course workflow into a two-week adoption plan.

Complete `my-two-week-plan.md` with:
- one named upcoming production ticket;
- the Explore → Plan → Code → Commit workflow mapped to that ticket;
- the habit most likely to be lost (for example, verification or avoiding prompt sprawl);
- a named protector for that habit;
- a specific, checkable definition of done;
- a day-14 review date;
- a plan-versus-actual retrospective entry.

Do not put customer data, credentials, tokens, or confidential production information in this file.
