# Lab 5 starter — Prompting for Effective Collaboration

## Goal
Compare vague and precise prompts against the under-documented scheduler, verify the answer against source code, request alternatives/trade-offs, and create reusable prompt snippets.

## Starting state
Start from the baseline/main behavior with Lab 3 onboarding present. This lab should not inherit the Lab 4 feature branch.

## Participant deliverables
- `docs/prompt-library.md` with four reusable prompt snippets.
- `notes/scheduler-note.md` in which every factual claim is tagged as verified or unverified and backed by evidence.
- Exported prompt experiments if the lab instructions request them.

## Core experiment
Ask first: `Explain how the scheduler works.`
Then use the four-part prompt from the lab guide: objective, constraints, context, definition of done. Verify every claim before it is shared.
