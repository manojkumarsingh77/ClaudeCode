# Lab 8 starter — Capstone: The Cold Ticket

## Ticket
SUP-4417 — one-line customer complaint: duplicate alerts are being delivered when a retry follows an acknowledgement loss.

## Starting state
Baseline application behavior with Lab 3 onboarding present. The learner receives the ticket with no solution scaffolding and must independently perform Explore → Plan → Code → Commit.

## What is intentionally seeded
The simulated provider can record a delivery and then lose the acknowledgement. The scheduler retries without passing an idempotency key, so the retry can be treated as a new delivery.

## Rules of engagement
- Work independently until the time box expires.
- Do not modify unrelated behavior.
- Add a regression test that would fail on the baseline defect.
- Validate the fix with the instructor acceptance suite when provided.
- Do not use the instructor reference patch as the primary solution path.

## Acceptance evidence
The instructor acceptance suite `duplicate-alerts.acceptance.test.js` is kept outside the participant project and is supplied at the checkpoint.
