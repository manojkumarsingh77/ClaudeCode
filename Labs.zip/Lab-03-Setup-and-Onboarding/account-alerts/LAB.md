# Lab 3 starter — Setup & Onboarding a Repo

## Goal
Onboard Claude Code to the repository safely: permissions, project instructions, secrets handling, read-only exploration, and an onboarding checklist.

## Starting state
Baseline repository. Participants are expected to create `.claude/settings.json`, `CLAUDE.md`, and the onboarding notes as part of the lab.

## Safety boundary
Everything is local or against the participant's own sandbox Git repository. No deployment target is required.

## Key areas to inspect
- `src/routes/alerts.js`
- `src/scheduler/deliveryScheduler.js`
- `src/scheduler/retryPolicy.js`
- `config/default.json`
- `.github/pull_request_template.md`

## Deliverable
The Lab 3 branch should contain the project-level Claude settings and `CLAUDE.md`, plus the onboarding checklist/evidence required by the lab. Production code should remain unchanged.
