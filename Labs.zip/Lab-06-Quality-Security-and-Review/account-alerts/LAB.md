# Lab 6 starter — Quality, Security & Reviewable PRs

## Goal
Harden the QH-101 quiet-hours change for enterprise review: verification, static analysis, reproducibility, secret blocking, dependency checks, prompt-injection awareness, IP/compliance review, human gates, blast-radius analysis, and PR accountability.

## Starting state
This copy contains a completed QH-101 implementation and tests, while the known duplicate-alert defect remains intentionally unfixed. Participants should treat the QH-101 branch as the change under review.

## Required review artifacts
- test/lint/coverage evidence
- clean-clone/rebuild evidence
- secret-blocking commit hook
- prompt-injection drill result
- dependency/IP/compliance checks
- human-in-the-loop review gates and escalation points
- blast-radius reproduction showing the duplicate-alert issue is pre-existing
- PR description with `What AI did` and `What a human validated`

## Important
Do not fix SUP-4417 in this lab. The duplicate-alert defect is the Lab 8 capstone ticket.
