'use strict';
function toMinutes(hhmm) { const [h,m]=hhmm.split(':').map(Number); return h*60+m; }
function localMinuteOfDay(date,timeZone) {
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);
  const get=t=>Number(parts.find(p=>p.type===t).value); return get('hour')*60+get('minute');
}
function isQuiet(date,timeZone,{start,end}) {
  const cur=localMinuteOfDay(date,timeZone), s=toMinutes(start), e=toMinutes(end);
  if (s===e) return false;
  return s<e ? cur>=s && cur<e : cur>=s || cur<e;
}
function quietEndsAt(date,timeZone,{end}) {
  const cur=localMinuteOfDay(date,timeZone); const mins=(toMinutes(end)-cur+1440)%1440 || 1440;
  const intoMinuteMs=date.getUTCSeconds()*1000+date.getUTCMilliseconds();
  return new Date(date.getTime()-intoMinuteMs+mins*60000);
}
module.exports={isQuiet,quietEndsAt};
