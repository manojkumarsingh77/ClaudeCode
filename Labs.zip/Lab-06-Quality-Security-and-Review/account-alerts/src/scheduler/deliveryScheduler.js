'use strict';
const {nextDelayMs}=require('./retryPolicy');
const {isQuiet,quietEndsAt}=require('./quietHours');
class DeliveryScheduler {
  constructor({store,provider,clock,config,random=Math.random}) {
    this.store=store; this.provider=provider; this.clock=clock; this.config=config; this.random=random;
    this.running=false; this.timer=null;
  }
  async tick() {
    if (this.running) return {skipped:true};
    this.running=true;
    const stats={sent:0,failed:0,dead:0,attempted:0};
    try {
      const due=this.store.listDue(this.clock.now());
      for (const a of due) {
        stats.attempted += 1;
        a.attempts += 1;
        try {
          const res=await this.provider.send({channel:a.channel,to:a.to,body:a.message});
          a.status='sent'; a.nextAttemptAt=null; this.store.save(a); stats.sent += 1;
        } catch (err) {
          stats.failed += 1;
          if (a.attempts >= this.config.retry.maxAttempts) {
            a.status='dead'; a.nextAttemptAt=null; stats.dead += 1;
          } else {
            const delay=nextDelayMs(a.attempts,this.config.retry,this.random);
            a.nextAttemptAt=new Date(this.clock.now().getTime()+delay).toISOString();
          }
          this.store.save(a);
        }
      }
      return stats;
    } finally { this.running=false; }
  }
  start() { if (this.timer) return; this.timer=setInterval(()=>this.tick(), this.config.scheduler.intervalMs); }
  stop() { if (this.timer) clearInterval(this.timer); this.timer=null; }
}
module.exports={DeliveryScheduler};
