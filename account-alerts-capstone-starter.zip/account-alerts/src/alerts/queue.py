"""In-memory stand-in for the account-events topic subscription.

Semantics match production (at-least-once): a message that is not acked is redelivered,
with delivery_count incremented, until max_deliveries, then moved to the dead-letter list.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, replace

from .models import AccountEvent


@dataclass(frozen=True)
class QueueMessage:
    message_id: str
    event: AccountEvent
    delivery_count: int = 1


class InMemoryQueue:
    def __init__(self, max_deliveries: int = 5):
        self.max_deliveries = max_deliveries
        self._pending: deque[QueueMessage] = deque()
        self.acked: list[QueueMessage] = []
        self.dead_letter: list[QueueMessage] = []
        self._seq = 0

    def publish(self, event: AccountEvent) -> QueueMessage:
        self._seq += 1
        message = QueueMessage(message_id=f"msg-{self._seq}", event=event)
        self._pending.append(message)
        return message

    def receive(self) -> QueueMessage | None:
        return self._pending.popleft() if self._pending else None

    def ack(self, message: QueueMessage) -> None:
        self.acked.append(message)

    def nack(self, message: QueueMessage) -> None:
        if message.delivery_count >= self.max_deliveries:
            self.dead_letter.append(message)
            return
        self._pending.append(replace(message, delivery_count=message.delivery_count + 1))

    def __len__(self) -> int:
        return len(self._pending)
