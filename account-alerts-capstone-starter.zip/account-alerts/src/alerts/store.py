"""Delivery store. Production uses the alerts_delivery Postgres table; this is the
in-memory implementation with the same interface, used by tests and local runs."""
from __future__ import annotations

import threading
from dataclasses import dataclass

from .models import DeliveryStatus


@dataclass(frozen=True)
class DeliveryRecord:
    alert_id: str
    status: DeliveryStatus
    attempts: int
    message_id: str | None = None
    reason: str | None = None


class DeliveryStore:
    def __init__(self) -> None:
        self._records: dict[str, DeliveryRecord] = {}
        self._lock = threading.Lock()

    def get(self, alert_id: str) -> DeliveryRecord | None:
        with self._lock:
            return self._records.get(alert_id)

    def was_delivered(self, alert_id: str) -> bool:
        record = self.get(alert_id)
        return record is not None and record.status is DeliveryStatus.DELIVERED

    def mark_delivered(self, alert_id: str, message_id: str, attempts: int) -> None:
        with self._lock:
            self._records[alert_id] = DeliveryRecord(alert_id, DeliveryStatus.DELIVERED, attempts, message_id)

    def mark_failed(self, alert_id: str, reason: str, attempts: int) -> None:
        with self._lock:
            self._records[alert_id] = DeliveryRecord(alert_id, DeliveryStatus.FAILED, attempts, reason=reason)

    def all(self) -> list[DeliveryRecord]:
        with self._lock:
            return list(self._records.values())
