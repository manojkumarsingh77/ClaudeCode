"""Customer profile lookup. Production reads the customer-preferences service."""
from __future__ import annotations

from .models import CustomerProfile


class InMemoryProfileRepository:
    def __init__(self, profiles: list[CustomerProfile] | None = None):
        self._profiles = {p.account_id: p for p in (profiles or [])}

    def get(self, account_id: str) -> CustomerProfile | None:
        return self._profiles.get(account_id)

    def add(self, profile: CustomerProfile) -> None:
        self._profiles[profile.account_id] = profile
