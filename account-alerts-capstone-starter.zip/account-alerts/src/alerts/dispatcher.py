"""Sends a single Alert through the SMS provider with retries."""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

from .masking import mask_account
from .models import Alert, DeliveryStatus
from .provider import NotificationProvider, PermanentProviderError, TransientProviderError
from .retry import RetryPolicy
from .store import DeliveryStore
from .templates import render_sms

logger = logging.getLogger("alerts.dispatcher")


class DispatchError(Exception):
    def __init__(self, message: str, retryable: bool):
        super().__init__(message)
        self.retryable = retryable


@dataclass(frozen=True)
class DispatchResult:
    alert_id: str
    status: DeliveryStatus | None
    attempts: int
    message_id: str | None = None
    skipped: bool = False


class AlertDispatcher:
    def __init__(self, provider: NotificationProvider, store: DeliveryStore, policy: RetryPolicy | None = None):
        self.provider = provider
        self.store = store
        self.policy = policy or RetryPolicy()

    def dispatch(self, alert: Alert) -> DispatchResult:
        if self.store.was_delivered(alert.alert_id):
            logger.info("alert %s already delivered, skipping", alert.alert_id)
            return DispatchResult(alert.alert_id, DeliveryStatus.DELIVERED, 0, skipped=True)

        body = render_sms(alert)
        attempt = 0
        while True:
            attempt += 1
            # Fresh request id per attempt so each call is traceable in TextLink's console (ALRT-112).
            request_id = uuid.uuid4().hex
            try:
                receipt = self.provider.send(alert.recipient.phone, body, idempotency_key=request_id)
            except PermanentProviderError as exc:
                self.store.mark_failed(alert.alert_id, str(exc), attempt)
                logger.error("alert %s permanently failed for %s: %s",
                             alert.alert_id, mask_account(alert.account_id), exc)
                raise DispatchError(str(exc), retryable=False) from exc
            except TransientProviderError as exc:
                logger.warning("alert %s attempt %d/%d failed for %s: %s", alert.alert_id, attempt,
                               self.policy.max_attempts, mask_account(alert.account_id), exc)
                if attempt >= self.policy.max_attempts:
                    self.store.mark_failed(alert.alert_id, str(exc), attempt)
                    raise DispatchError(str(exc), retryable=True) from exc
                self.policy.sleeper(self.policy.delay_for(attempt))
                continue

            self.store.mark_delivered(alert.alert_id, receipt.message_id, attempt)
            logger.info("alert %s type=%s delivered to %s message_id=%s attempts=%d",
                        alert.alert_id, alert.alert_type.value, mask_account(alert.account_id),
                        receipt.message_id, attempt)
            return DispatchResult(alert.alert_id, DeliveryStatus.DELIVERED, attempt, receipt.message_id)
