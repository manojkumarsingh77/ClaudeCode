"""Domain models shared with other services. Do not rename or remove fields."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum


class AlertType(str, Enum):
    LOW_BALANCE = "LOW_BALANCE"
    LARGE_TRANSACTION = "LARGE_TRANSACTION"
    FAILED_LOGIN = "FAILED_LOGIN"


class EventType(str, Enum):
    CARD_TRANSACTION = "CARD_TRANSACTION"
    BALANCE_UPDATED = "BALANCE_UPDATED"
    LOGIN_FAILED = "LOGIN_FAILED"


class Channel(str, Enum):
    SMS = "SMS"
    EMAIL = "EMAIL"


@dataclass(frozen=True)
class AccountEvent:
    """An event published by core banking onto the account-events topic."""
    event_id: str
    account_id: str
    event_type: EventType
    occurred_at: datetime
    amount: Decimal = Decimal("0")
    balance: Decimal = Decimal("0")
    merchant: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Recipient:
    phone: str
    email: str
    channel: Channel = Channel.SMS


@dataclass(frozen=True)
class CustomerProfile:
    account_id: str
    first_name: str
    recipient: Recipient
    low_balance_threshold: Decimal = Decimal("100.00")
    large_transaction_threshold: Decimal = Decimal("500.00")
    currency: str = "GBP"


@dataclass(frozen=True)
class Alert:
    alert_id: str
    alert_type: AlertType
    account_id: str
    event_id: str
    recipient: Recipient
    payload: dict


@dataclass(frozen=True)
class DeliveryReceipt:
    message_id: str
    provider_status: str


class DeliveryStatus(str, Enum):
    DELIVERED = "DELIVERED"
    FAILED = "FAILED"
