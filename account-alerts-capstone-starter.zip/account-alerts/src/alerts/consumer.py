"""Consumes account events, evaluates rules and dispatches the resulting alerts."""
from __future__ import annotations

import logging

from .dispatcher import AlertDispatcher, DispatchError
from .masking import mask_account
from .profiles import InMemoryProfileRepository
from .queue import InMemoryQueue
from .rules import evaluate

logger = logging.getLogger("alerts.consumer")


class EventConsumer:
    def __init__(self, queue: InMemoryQueue, profiles: InMemoryProfileRepository, dispatcher: AlertDispatcher):
        self.queue = queue
        self.profiles = profiles
        self.dispatcher = dispatcher

    def process_one(self) -> bool:
        """Process one message. Returns False when the queue is empty."""
        message = self.queue.receive()
        if message is None:
            return False

        event = message.event
        profile = self.profiles.get(event.account_id)
        if profile is None:
            logger.warning("no profile for %s, dropping event %s", mask_account(event.account_id), event.event_id)
            self.queue.ack(message)
            return True

        try:
            for alert in evaluate(event, profile):
                self.dispatcher.dispatch(alert)
        except DispatchError as exc:
            if exc.retryable:
                logger.warning("event %s delivery %d failed, returning to queue: %s",
                               event.event_id, message.delivery_count, exc)
                self.queue.nack(message)
            else:
                logger.error("event %s has a permanent failure, acking: %s", event.event_id, exc)
                self.queue.ack(message)
            return True

        self.queue.ack(message)
        return True

    def drain(self, max_messages: int = 10_000) -> int:
        processed = 0
        while processed < max_messages and self.process_one():
            processed += 1
        return processed
