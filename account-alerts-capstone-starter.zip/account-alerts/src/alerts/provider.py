"""SMS provider clients.

Production uses TextLink (HTTP API). TextLink honours the `Idempotency-Key` header for
24 hours: a repeated key returns the original message receipt and does NOT send again.

TextLink's gateway times out at 5 s. A timeout does not mean the message was not sent:
TextLink frequently accepts the request and delivers it after the gateway has given up.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Protocol

from .models import DeliveryReceipt


class ProviderError(Exception):
    """Base class for provider failures."""


class TransientProviderError(ProviderError):
    """Safe to retry: 429, 5xx, connection reset."""


class ProviderTimeout(TransientProviderError):
    """Gateway timed out. The request MAY have been processed by the provider."""


class PermanentProviderError(ProviderError):
    """Do not retry: invalid number, opted-out recipient, 4xx other than 429."""


class NotificationProvider(Protocol):
    def send(self, to: str, body: str, idempotency_key: str) -> DeliveryReceipt: ...


class TextLinkProvider:
    """Thin HTTP client for the TextLink SMS API (not exercised in unit tests)."""

    def __init__(self, base_url: str, api_key: str, timeout_s: float = 5.0):
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout_s = timeout_s

    def send(self, to: str, body: str, idempotency_key: str) -> DeliveryReceipt:
        request = urllib.request.Request(
            f"{self._base_url}/v2/messages",
            data=json.dumps({"to": to, "body": body}).encode(),
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Idempotency-Key": idempotency_key,
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self._timeout_s) as response:
                data = json.loads(response.read())
        except TimeoutError as exc:
            raise ProviderTimeout("TextLink gateway timeout") from exc
        except urllib.error.HTTPError as exc:
            if exc.code == 429 or exc.code >= 500:
                raise TransientProviderError(f"TextLink HTTP {exc.code}") from exc
            raise PermanentProviderError(f"TextLink HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise TransientProviderError("TextLink connection error") from exc
        return DeliveryReceipt(message_id=data["sid"], provider_status=data["status"])


class FakeSmsProvider:
    """In-memory TextLink stand-in with scripted behaviour, used by tests and local runs.

    `script` is consumed one entry per *new* request (a repeated idempotency key never
    consumes a script entry, exactly like TextLink). Behaviours:
      "ok"                   accept and deliver
      "reject_transient"     raise TransientProviderError, nothing delivered
      "reject_permanent"     raise PermanentProviderError, nothing delivered
      "timeout_after_accept" deliver to the handset, then raise ProviderTimeout
    `handset` records what the customer actually received.
    """

    def __init__(self, script: list[str] | None = None):
        self.script = list(script or [])
        self.calls: list[dict] = []
        self.handset: list[dict] = []
        self._receipts_by_key: dict[str, DeliveryReceipt] = {}

    def send(self, to: str, body: str, idempotency_key: str) -> DeliveryReceipt:
        self.calls.append({"to": to, "body": body, "idempotency_key": idempotency_key})
        if idempotency_key in self._receipts_by_key:
            return self._receipts_by_key[idempotency_key]

        behaviour = self.script.pop(0) if self.script else "ok"
        if behaviour == "reject_transient":
            raise TransientProviderError("TextLink HTTP 503")
        if behaviour == "reject_permanent":
            raise PermanentProviderError("TextLink HTTP 400 invalid number")

        receipt = DeliveryReceipt(message_id=f"SM{len(self.handset) + 1:06d}", provider_status="queued")
        self.handset.append({"to": to, "body": body, "message_id": receipt.message_id})
        self._receipts_by_key[idempotency_key] = receipt
        if behaviour == "timeout_after_accept":
            raise ProviderTimeout("TextLink gateway timeout")
        return receipt
