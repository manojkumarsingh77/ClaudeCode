"""Alert rules: turn an AccountEvent into zero or more Alerts for a customer."""
from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Callable

from .models import AccountEvent, Alert, AlertType, CustomerProfile, EventType

Rule = Callable[[AccountEvent, CustomerProfile], "Alert | None"]


def _new_alert(alert_type: AlertType, event: AccountEvent, profile: CustomerProfile, payload: dict) -> Alert:
    return Alert(
        alert_id=uuid.uuid4().hex,
        alert_type=alert_type,
        account_id=event.account_id,
        event_id=event.event_id,
        recipient=profile.recipient,
        payload=payload,
    )


def low_balance(event: AccountEvent, profile: CustomerProfile) -> Alert | None:
    if event.event_type not in (EventType.CARD_TRANSACTION, EventType.BALANCE_UPDATED):
        return None
    if event.balance >= profile.low_balance_threshold:
        return None
    return _new_alert(AlertType.LOW_BALANCE, event, profile, {
        "first_name": profile.first_name,
        "balance": event.balance.quantize(Decimal("1")),
        "currency": profile.currency,
    })


def large_transaction(event: AccountEvent, profile: CustomerProfile) -> Alert | None:
    if event.event_type is not EventType.CARD_TRANSACTION:
        return None
    if event.amount < profile.large_transaction_threshold:
        return None
    return _new_alert(AlertType.LARGE_TRANSACTION, event, profile, {
        "first_name": profile.first_name,
        "amount": event.amount,
        "currency": profile.currency,
        "merchant": event.merchant or "a merchant",
    })


def failed_login(event: AccountEvent, profile: CustomerProfile) -> Alert | None:
    if event.event_type is not EventType.LOGIN_FAILED:
        return None
    if int(event.metadata.get("consecutive_failures", 0)) < 3:
        return None
    return _new_alert(AlertType.FAILED_LOGIN, event, profile, {"first_name": profile.first_name})


# Evaluation order matters: customers expect the transaction alert before the balance alert.
RULES: dict[AlertType, Rule] = {
    AlertType.LARGE_TRANSACTION: large_transaction,
    AlertType.LOW_BALANCE: low_balance,
    AlertType.FAILED_LOGIN: failed_login,
}


def evaluate(event: AccountEvent, profile: CustomerProfile) -> list[Alert]:
    alerts = []
    for rule in RULES.values():
        alert = rule(event, profile)
        if alert is not None:
            alerts.append(alert)
    return alerts
