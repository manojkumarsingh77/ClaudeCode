"""Message templates. SMS bodies must render to 160 characters or fewer."""
from __future__ import annotations

from decimal import Decimal

from .models import Alert, AlertType

SMS_TEMPLATES: dict[str, str] = {
    AlertType.LOW_BALANCE.value: (
        "Hi {first_name}, your balance is now below {currency} {balance}. "
        "Check the app to avoid fees. Reply STOP to opt out"
    ),
    AlertType.LARGE_TRANSACTION.value: (
        "Hi {first_name}, {currency} {amount} paid to {merchant} on your card. "
        "Not you? Call 0800 000 111. Reply STOP to opt out"
    ),
    AlertType.FAILED_LOGIN.value: (
        "Hi {first_name}, we blocked 3 failed sign-in attempts on your account. "
        "Not you? Call 0800 000 111. Reply STOP to opt out"
    ),
}

EMAIL_SUBJECTS: dict[str, str] = {
    AlertType.LOW_BALANCE.value: "Your balance is running low",
    AlertType.LARGE_TRANSACTION.value: "Large payment on your card",
    AlertType.FAILED_LOGIN.value: "Failed sign-in attempts on your account",
}

_PREVIEW_DATA = {
    "first_name": "Alexandria",
    "currency": "GBP",
    "balance": Decimal("99"),
    "amount": Decimal("12500.00"),
    "merchant": "INTERNATIONAL AIRLINES GROUP",
}


def render_sms(alert: Alert) -> str:
    template = SMS_TEMPLATES[alert.alert_type.value]
    return template.format(**alert.payload)


def render_sms_preview(key: str) -> str:
    """Render a template with worst-case sample data (long name, long merchant)."""
    return SMS_TEMPLATES[key].format(**_PREVIEW_DATA)
