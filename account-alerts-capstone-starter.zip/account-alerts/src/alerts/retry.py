"""Retry policy for provider calls: capped exponential backoff."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class RetryPolicy:
    max_attempts: int = 3
    base_delay_s: float = 0.5
    max_delay_s: float = 4.0
    sleeper: Callable[[float], None] = field(default=time.sleep, repr=False)

    def delay_for(self, attempt: int) -> float:
        """Delay after the given (1-based) failed attempt."""
        return min(self.max_delay_s, self.base_delay_s * (2 ** (attempt - 1)))
