"""PII masking helpers. Use these for every log line and exception message."""


def mask_account(account_id: str) -> str:
    digits = "".join(ch for ch in account_id if ch.isdigit())
    return "****" + digits[-4:] if len(digits) >= 4 else "****"


def mask_phone(phone: str) -> str:
    digits = "".join(ch for ch in phone if ch.isdigit())
    return "*******" + digits[-3:] if len(digits) >= 3 else "*******"


def mask_email(email: str) -> str:
    if "@" not in email:
        return "***"
    local, domain = email.split("@", 1)
    return (local[:1] or "*") + "***@" + domain
