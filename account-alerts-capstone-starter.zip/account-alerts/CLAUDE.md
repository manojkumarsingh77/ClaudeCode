# account-alerts

Bank notification service: consumes account events, evaluates alert rules,
sends SMS/email via a provider with retries. Python 3.11, stdlib + pytest only.

## Commands
- Test: `python3 -m pytest -q`
- Single test: `python3 -m pytest tests/test_dispatcher.py -q -k <name>`
- Lint: `python3 -m pyflakes src tests` (install if missing)

## Workflow
- Explore -> Plan -> Code -> Commit. Plan first for any change touching dispatcher.py or store.py.
- Every bug fix ships with a failing-first regression test.
- Commit format: `ALRT-<id>: <imperative summary>`; one logical change per commit.

## Architecture
@docs/ARCHITECTURE.md

## Do not
- Do not add third-party dependencies without an ADR in docs/adr/.
- Do not change public dataclass fields in models.py (consumed by other services).
