from decimal import Decimal

from alerts.models import AlertType, EventType
from alerts.rules import evaluate


def test_small_transaction_healthy_balance_no_alert(profile, event_factory):
    assert evaluate(event_factory(amount="25.00", balance="1200.00"), profile) == []


def test_large_transaction_alert(profile, event_factory):
    alerts = evaluate(event_factory(amount="640.00", balance="900.00"), profile)
    assert [a.alert_type for a in alerts] == [AlertType.LARGE_TRANSACTION]
    assert alerts[0].payload["amount"] == Decimal("640.00")


def test_large_transaction_that_drops_balance_raises_two_alerts_in_order(profile, event_factory):
    alerts = evaluate(event_factory(amount="640.00", balance="42.10"), profile)
    assert [a.alert_type for a in alerts] == [AlertType.LARGE_TRANSACTION, AlertType.LOW_BALANCE]


def test_low_balance_rounds_for_sms(profile, event_factory):
    alerts = evaluate(event_factory(event_type=EventType.BALANCE_UPDATED, amount="0", balance="42.60"), profile)
    assert alerts[0].payload["balance"] == Decimal("43")


def test_failed_login_needs_three_failures(profile, event_factory):
    two = event_factory(event_type=EventType.LOGIN_FAILED, metadata={"consecutive_failures": 2})
    three = event_factory(event_type=EventType.LOGIN_FAILED, metadata={"consecutive_failures": 3})
    assert evaluate(two, profile) == []
    assert [a.alert_type for a in evaluate(three, profile)] == [AlertType.FAILED_LOGIN]


def test_alert_carries_event_reference(profile, event_factory):
    alert = evaluate(event_factory(event_id="evt-777", amount="900.00"), profile)[0]
    assert alert.event_id == "evt-777"
    assert alert.account_id == profile.account_id
