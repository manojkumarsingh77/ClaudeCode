import pytest

from alerts.dispatcher import AlertDispatcher, DispatchError
from alerts.models import DeliveryStatus
from alerts.provider import FakeSmsProvider
from alerts.rules import evaluate


@pytest.fixture
def large_txn_alert(profile, event_factory):
    return evaluate(event_factory(amount="640.00"), profile)[0]


def test_delivers_first_time(large_txn_alert, store, no_sleep_policy):
    provider = FakeSmsProvider(script=["ok"])
    result = AlertDispatcher(provider, store, no_sleep_policy).dispatch(large_txn_alert)
    assert result.status is DeliveryStatus.DELIVERED
    assert result.attempts == 1
    assert len(provider.handset) == 1
    assert store.was_delivered(large_txn_alert.alert_id)


def test_retries_transient_rejection_then_delivers(large_txn_alert, store, no_sleep_policy):
    provider = FakeSmsProvider(script=["reject_transient", "ok"])
    result = AlertDispatcher(provider, store, no_sleep_policy).dispatch(large_txn_alert)
    assert result.attempts == 2
    assert len(provider.handset) == 1


def test_gives_up_after_max_attempts(large_txn_alert, store, no_sleep_policy):
    provider = FakeSmsProvider(script=["reject_transient"] * 3)
    with pytest.raises(DispatchError) as info:
        AlertDispatcher(provider, store, no_sleep_policy).dispatch(large_txn_alert)
    assert info.value.retryable is True
    assert store.get(large_txn_alert.alert_id).status is DeliveryStatus.FAILED
    assert len(provider.calls) == 3


def test_permanent_error_is_not_retried(large_txn_alert, store, no_sleep_policy):
    provider = FakeSmsProvider(script=["reject_permanent"])
    with pytest.raises(DispatchError) as info:
        AlertDispatcher(provider, store, no_sleep_policy).dispatch(large_txn_alert)
    assert info.value.retryable is False
    assert len(provider.calls) == 1


def test_backoff_delays_are_applied(large_txn_alert, store):
    from alerts.retry import RetryPolicy
    slept = []
    policy = RetryPolicy(max_attempts=3, base_delay_s=0.5, sleeper=slept.append)
    provider = FakeSmsProvider(script=["reject_transient", "reject_transient", "ok"])
    AlertDispatcher(provider, store, policy).dispatch(large_txn_alert)
    assert slept == [0.5, 1.0]


def test_already_delivered_alert_is_skipped(large_txn_alert, store, no_sleep_policy):
    provider = FakeSmsProvider()
    dispatcher = AlertDispatcher(provider, store, no_sleep_policy)
    dispatcher.dispatch(large_txn_alert)
    result = dispatcher.dispatch(large_txn_alert)
    assert result.skipped is True
    assert len(provider.handset) == 1
