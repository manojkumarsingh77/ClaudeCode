from alerts.models import EventType


def test_happy_path_sends_and_acks(build_consumer, event_factory):
    consumer, queue, provider = build_consumer()
    queue.publish(event_factory(amount="640.00", balance="900.00"))
    consumer.drain()
    assert len(provider.handset) == 1
    assert len(queue.acked) == 1


def test_event_without_alerts_is_acked(build_consumer, event_factory):
    consumer, queue, provider = build_consumer()
    queue.publish(event_factory(amount="10.00", balance="900.00"))
    consumer.drain()
    assert provider.handset == []
    assert len(queue.acked) == 1


def test_unknown_account_is_dropped(build_consumer, event_factory):
    consumer, queue, provider = build_consumer()
    queue.publish(event_factory(account_id="99-99-99-00000001", amount="900.00"))
    consumer.drain()
    assert provider.handset == []
    assert len(queue.acked) == 1


def test_retryable_failure_returns_event_to_queue(build_consumer, event_factory):
    consumer, queue, provider = build_consumer(script=["reject_transient"] * 3)
    queue.publish(event_factory(amount="640.00", balance="900.00"))
    consumer.process_one()
    assert len(queue) == 1
    assert queue.acked == []


def test_permanent_failure_is_acked_not_redelivered(build_consumer, event_factory):
    consumer, queue, provider = build_consumer(script=["reject_permanent"])
    queue.publish(event_factory(event_type=EventType.LOGIN_FAILED, metadata={"consecutive_failures": 4}))
    consumer.drain()
    assert len(queue) == 0
    assert len(queue.acked) == 1
