import pytest

from alerts.templates import SMS_TEMPLATES, render_sms_preview


@pytest.mark.parametrize("key", sorted(SMS_TEMPLATES))
def test_sms_fits_single_segment(key):
    assert len(render_sms_preview(key)) <= 160


@pytest.mark.parametrize("key", sorted(SMS_TEMPLATES))
def test_sms_has_opt_out(key):
    assert render_sms_preview(key).endswith("Reply STOP to opt out")
