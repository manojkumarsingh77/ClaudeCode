from datetime import datetime, timezone
from decimal import Decimal

import pytest

from alerts.dispatcher import AlertDispatcher
from alerts.models import AccountEvent, CustomerProfile, EventType, Recipient
from alerts.profiles import InMemoryProfileRepository
from alerts.provider import FakeSmsProvider
from alerts.queue import InMemoryQueue
from alerts.retry import RetryPolicy
from alerts.store import DeliveryStore


@pytest.fixture
def profile():
    return CustomerProfile(
        account_id="40-11-22-73418812",
        first_name="Priya",
        recipient=Recipient(phone="+447700900123", email="priya@example.com"),
    )


@pytest.fixture
def no_sleep_policy():
    return RetryPolicy(max_attempts=3, sleeper=lambda _s: None)


@pytest.fixture
def store():
    return DeliveryStore()


def make_event(event_id="evt-001", amount="25.00", balance="1200.00",
               event_type=EventType.CARD_TRANSACTION, account_id="40-11-22-73418812", **kw):
    return AccountEvent(
        event_id=event_id,
        account_id=account_id,
        event_type=event_type,
        occurred_at=datetime(2026, 9, 21, 18, 42, tzinfo=timezone.utc),
        amount=Decimal(amount),
        balance=Decimal(balance),
        merchant=kw.pop("merchant", "TESCO STORES 2231"),
        metadata=kw.pop("metadata", {}),
    )


@pytest.fixture
def event_factory():
    return make_event


@pytest.fixture
def build_consumer(profile, store, no_sleep_policy):
    def _build(script=None):
        provider = FakeSmsProvider(script=script)
        queue = InMemoryQueue()
        dispatcher = AlertDispatcher(provider, store, no_sleep_policy)
        from alerts.consumer import EventConsumer
        consumer = EventConsumer(queue, InMemoryProfileRepository([profile]), dispatcher)
        return consumer, queue, provider
    return _build
