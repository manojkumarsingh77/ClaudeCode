from alerts.masking import mask_account, mask_email, mask_phone


def test_mask_account_keeps_last_four():
    assert mask_account("40-11-22-73418812") == "****8812"


def test_mask_phone_keeps_last_three():
    assert mask_phone("+447700900123") == "*******123"


def test_mask_email():
    assert mask_email("priya@example.com") == "p***@example.com"
