# account-alerts runbook

## Customer reports missing alert
1. Find the account in the delivery log (alerts-ops MCP `search_delivery_log`, last 4 digits).
2. `FAILED` + `invalid number` or `opted out`: not a defect; route to Customer Care.
3. No record at all: check the DLQ for the event id.

## Customer reports duplicate alert
1. Find all deliveries for the account and alert type in the delivery log.
2. Group by `event_id`. More than one `accepted` message for one event and alert type is a defect.
3. Raise a P2 in ALRT. Duplicate fraud-style alerts drive call-centre volume and
   customers ignoring genuine alerts.

## DLQ replay
Replay is safe only if dispatch is idempotent per event and alert type.
