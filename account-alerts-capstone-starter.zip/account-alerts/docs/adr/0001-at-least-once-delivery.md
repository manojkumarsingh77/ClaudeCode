# ADR-0001: Consume account-events with at-least-once delivery

Status: Accepted (2025-03-11)

## Context
The account-events topic supports at-least-once delivery with ack/nack. Exactly-once
would require transactional outbox support that core banking does not provide.

## Decision
The consumer acks a message only after every alert for that event has been dispatched.
Any retryable failure nacks the whole message so the event is redelivered.

## Consequences
- An event can be processed more than once. Downstream side effects must be idempotent.
- The broker may also redeliver after a consumer crash or rebalance, independent of nack.
