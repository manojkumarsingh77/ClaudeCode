# ADR-0002: TextLink as SMS provider

Status: Accepted (2025-06-02)

TextLink chosen for UK delivery rates and 24-hour idempotency-key support.
Gateway timeout is fixed at 5 s; a timeout does not imply non-delivery.
