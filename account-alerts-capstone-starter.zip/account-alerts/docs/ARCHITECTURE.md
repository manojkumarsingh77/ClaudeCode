# account-alerts architecture

```
core-banking --> [account-events topic] --> EventConsumer --> rules.evaluate()
                  (at-least-once, see ADR-0001)            |
                                                           v
                                     AlertDispatcher --retry--> TextLink SMS API
                                           |
                                           v
                                     DeliveryStore (alerts_delivery table)
```

## Flow

1. `EventConsumer.process_one()` receives a message and loads the customer profile.
2. `rules.evaluate()` returns zero or more `Alert`s, in rule order.
3. `AlertDispatcher.dispatch()` sends each alert, retrying transient provider errors
   with capped exponential backoff (`RetryPolicy`, default 3 attempts).
4. If every alert succeeds, the message is acked. If any alert fails with a retryable
   error, the whole message is nacked and redelivered (up to 5 deliveries, then DLQ).

## Provider contract (TextLink)

- `Idempotency-Key` header honoured for 24 hours: a repeat returns the original receipt.
- Gateway timeout 5 s. Timeouts are ambiguous: the message may already be sent.
- 429 and 5xx are transient; other 4xx are permanent.

## Alert catalogue

| AlertType | Trigger | Channel | Owner |
| --- | --- | --- | --- |
| LARGE_TRANSACTION | Card transaction >= customer threshold (default GBP 500) | SMS | Cards Risk |
| LOW_BALANCE | Balance after event < customer threshold (default GBP 100) | SMS | Retail Product |
| FAILED_LOGIN | 3 or more consecutive failed sign-ins | SMS | Fraud Ops |
