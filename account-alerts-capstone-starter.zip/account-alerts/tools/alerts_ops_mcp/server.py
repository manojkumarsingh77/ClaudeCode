"""alerts-ops MCP server: ALRT tickets and masked delivery logs (training snapshot).

Run: python tools/alerts_ops_mcp/server.py   (stdio transport)
Register: claude mcp add alerts-ops --scope project -- .venv/bin/python tools/alerts_ops_mcp/server.py
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

try:  # mcp SDK 2.x
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # mcp SDK 1.x
    from mcp.server.fastmcp import FastMCP as _Server

DATA = Path(__file__).parent / "data"
mcp = _Server("alerts-ops")


def _tickets() -> dict:
    return json.loads((DATA / "tickets.json").read_text())


@mcp.tool()
def get_ticket(key: str) -> dict:
    """Return a Jira ticket from the ALRT project by key, e.g. ALRT-238."""
    ticket = _tickets().get(key.upper())
    return ticket or {"error": f"{key} not found"}


@mcp.tool()
def search_delivery_log(account_suffix: str = "", alert_type: str = "") -> list[dict]:
    """Search masked alert delivery logs. account_suffix = last 4 digits of the account
    (empty returns all accounts). Optionally filter by alert_type (LARGE_TRANSACTION,
    LOW_BALANCE, FAILED_LOGIN, PROVIDER_CALLBACK)."""
    rows = []
    for line in (DATA / "delivery_log.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row["account"].endswith(account_suffix) and (not alert_type or row["alert_type"] == alert_type):
            rows.append(row)
    return rows


@mcp.tool()
def add_ticket_comment(key: str, body: str) -> dict:
    """Add a comment to a ticket. The comment is visible to the whole team."""
    path = DATA / "comments.jsonl"
    entry = {"key": key.upper(), "body": body, "at": datetime.now(timezone.utc).isoformat()}
    with path.open("a") as f:
        f.write(json.dumps(entry) + "\n")
    return {"ok": True, **entry}


if __name__ == "__main__":
    mcp.run()
