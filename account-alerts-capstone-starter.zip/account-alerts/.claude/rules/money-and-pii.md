---
paths:
  - "src/**/*.py"
---
# Money and PII rules
- Monetary amounts are `decimal.Decimal`. Never `float`.
- Never log a full account number, phone or email. Use `alerts.masking.mask_account()`
  (renders `****1234`), `mask_phone()` or `mask_email()`.
- Alert bodies must not contain the full balance for SMS; round to whole currency units.
