# account-alerts

Customer alert service for Retail Banking. Consumes events from the `account-events`
topic, evaluates alert rules and sends SMS through TextLink.

Owner: Payments Notifications squad (#notifications-eng) · On-call: PagerDuty `alerts-oncall`

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python3 -m pytest -q
```

## Layout

| Path | Purpose |
| --- | --- |
| `src/alerts/rules.py` | Event -> alerts |
| `src/alerts/templates.py` | SMS/email copy (160-char SMS limit) |
| `src/alerts/dispatcher.py` | Provider call + retry for one alert |
| `src/alerts/consumer.py` | Queue loop: evaluate, dispatch, ack/nack |
| `src/alerts/store.py` | Delivery records (Postgres in prod, in-memory here) |
| `src/alerts/provider.py` | TextLink client + `FakeSmsProvider` for tests |
| `tools/alerts_ops_mcp/` | Team MCP server: tickets + masked delivery logs |
| `docs/` | Architecture, runbook, ADRs |
