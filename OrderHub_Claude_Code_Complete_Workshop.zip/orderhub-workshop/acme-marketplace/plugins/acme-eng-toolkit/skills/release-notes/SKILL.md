---
name: release-notes
description: Generates customer-facing release notes for OrderHub from Conventional Commits between two git refs. Use for release notes, changelog, or what shipped in a version or tag.
---
# Release notes
## Inputs
- FROM: previous release tag; ask if ambiguous.
- TO: HEAD unless specified.
- VERSION: ask if not given.
## Procedure
1. Run `git log --reverse --pretty=format:"%s" <FROM>..<TO>` in the consuming repository.
2. Parse each line as `type(JIRA-KEY): summary`. Track the full original commit line.
3. Map feat to New features, fix to Bug fixes, perf to Performance. Exclude chore, docs, test, ci and refactor.
4. Rewrite summaries into plain customer language without inventing facts; retain Jira keys in brackets.
5. Put any candidate feature, fix or performance commit without a Jira key in Needs triage only.
6. Fill this skill's `template.md` exactly and write `docs/releases/<VERSION>.md`.
7. Report section counts and flag the internal triage section for review before publishing.
## Rules
- Never add an item without a supporting commit.
- Do not publish the triage section externally.
