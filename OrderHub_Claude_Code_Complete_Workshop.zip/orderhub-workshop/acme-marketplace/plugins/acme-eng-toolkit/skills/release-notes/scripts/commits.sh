#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 || $# -gt 2 ]]; then echo 'Usage: commits.sh <from-ref> [to-ref]' >&2; exit 2; fi
git log --reverse --pretty=format:'%s' "$1..${2:-HEAD}"
printf '\n'
