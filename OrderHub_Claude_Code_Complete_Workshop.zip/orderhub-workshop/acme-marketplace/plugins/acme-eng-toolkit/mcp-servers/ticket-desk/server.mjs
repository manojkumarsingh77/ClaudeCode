import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { readFileSync } from 'node:fs';
const DATA = process.env.TICKETS_FILE ?? new URL('../../data/tickets.json', import.meta.url);
const load = () => JSON.parse(readFileSync(DATA, 'utf8'));
const text = (value) => ({ content: [{ type: 'text', text: value }] });
const server = new McpServer({ name: 'ticket-desk', version: '1.0.0' });
server.registerTool('list_tickets', { title: 'List tickets', description: 'List OrderHub tickets, optionally filtered by status.', inputSchema: { status: z.string().optional() } }, async ({ status }) => text(load().filter(t => !status || t.status === status).map(t => `${t.key} [${t.status}] ${t.summary}`).join('\n') || 'No tickets.'));
server.registerTool('get_ticket', { title: 'Get ticket', description: 'Get one ticket and its acceptance criteria by key.', inputSchema: { key: z.string() } }, async ({ key }) => {
  const ticket = load().find(t => t.key === key.toUpperCase());
  return ticket ? text(JSON.stringify(ticket, null, 2)) : { ...text(`Ticket ${key} not found.`), isError: true };
});
await server.connect(new StdioServerTransport());
