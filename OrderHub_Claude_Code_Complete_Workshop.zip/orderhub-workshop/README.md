# OrderHub Claude Code workshop — Labs 1–5

## Open in VS Code
1. Extract this ZIP, then open `orderhub-workshop/orderhub/` in VS Code.
2. Install Node.js 20+ and Claude Code. In the integrated terminal run `npm install` and `npm test`.
3. Open Claude Code in the **orderhub** folder. `git log --oneline --decorate` must show tag `v1.3.0` and five release commits.
4. Follow your supplied lab guide. Reference assets are in `../reference/`; copy each asset into the paths below *during* its lab, or write it yourself.

| Lab | Starting state and actions | Reference destination |
| --- | --- | --- |
| 1 | Run `/init`; curate instructions; test both probes | `reference/lab1/CLAUDE.md` → `orderhub/CLAUDE.md`; `docs/` → `orderhub/docs/`; `src/payments/CLAUDE.md` → same |
| 2 | Create skill, inspect commits since tag, generate release notes | `reference/lab2/release-notes/` → `orderhub/.claude/skills/release-notes/` |
| 3 | Review **deliberately vulnerable** `src/auth.js`; fix in main session | `reference/lab3/security-reviewer.md` → `orderhub/.claude/agents/security-reviewer.md` |
| 4 | Connect mock ticket server; fetch OHUB-231 and implement limit | `reference/lab4/{package.json,server.mjs}` → `orderhub/mcp-servers/ticket-desk/`; `.mcp.json` → `orderhub/` |
| 5 | Build plugin from completed Labs 2–4; install into `storefront/` | Run `bash ../scripts/build-plugin.sh` in `orderhub/`; see below |

The root has no preinstalled Claude instructions, skill or subagent: creating these files is the exercise. The fake API key and injection sinks in auth.js are **intentionally unsafe training defects**. Keep this project local; do not deploy it. The database query is a stub and does not execute SQL; the reviewer should still flag the unsafe SQL construction. `/reports/export` calls a real shell and is deliberately vulnerable until Lab 3.

## Lab 2 reproducible release history
`v1.3.0` points to the starter baseline. Later commit subjects have two features (UPI, invoice PDF), one fix (GST rounding), one performance change (catalogue cache), and one ignored chore (eslint). Lab 2 adds `fix: typo in receipt email` with `git commit --allow-empty` to exercise Needs triage. Before Lab 2, create and commit Lab 1 instructions as directed. Exclude the Lab 1 docs commit from release notes.

## Lab 4
Run `npm install` inside `mcp-servers/ticket-desk/` after copying files. `.mcp.json` uses a relative path. For a live connection, approve the server in Claude Code, then `/mcp`. Ticket data are local JSON, not a real Jira connection. The server reads `data/tickets.json`; unknown keys return MCP `isError: true`.

## Lab 5
A ready-to-inspect version 1.0.0 plugin is included in `acme-marketplace/plugins/acme-eng-toolkit/`. After Labs 2–4, rebuild it from your own lab work with `bash ../scripts/build-plugin.sh` from `orderhub/`. This copies the completed skill, agent, server, and tickets into `../acme-marketplace/plugins/acme-eng-toolkit/`; it changes the plugin skill script path to work in any consuming Git repo. The plugin server requires `npm install --omit=dev` in its bundled `mcp-servers/ticket-desk/` (network access needed). From the `storefront/` repo, run `/plugin marketplace add ../acme-marketplace`, then `/plugin install acme-eng-toolkit@acme-internal`. Verify with `/agents`, `/mcp`, and the skill command. The marketplace config in `reference/lab5/storefront-settings.local.example.json` is an illustration; for team-wide distribution, publish your own reachable marketplace and configure its actual Git repository. Version-bump both manifest and marketplace catalogue to 1.1.0 during the lab.

## Notes
Run `/` commands inside Claude Code, not Bash. Some VS Code panels expose fewer commands than the integrated Claude Code CLI. Restart the Claude session after adding project components. Commit changes inside `orderhub/`; `storefront/` has a separate Git history. If the package registry is blocked, preinstall npm dependencies in an allowed network environment; the ZIP does not include node_modules. See `scripts/check-project.sh` for offline structural checks.
