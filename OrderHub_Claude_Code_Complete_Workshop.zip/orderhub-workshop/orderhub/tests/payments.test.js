const { charge } = require('../src/payments/charge');
test('accepts integer paise only', () => {
  expect(charge({}, 500)).toEqual({ authorized: true, amountPaise: 500 });
  expect(() => charge({}, 5.5)).toThrow(RangeError);
});
