const { quote } = require('../src/orders');
test('quotes orders using integer paise', () => {
  expect(quote(1999, 2)).toBe(3998);
  expect(() => quote(19.99, 2)).toThrow(RangeError);
});
