const app = require('../src/app');
test('exposes the workshop API', () => { expect(typeof app).toBe('function'); });
