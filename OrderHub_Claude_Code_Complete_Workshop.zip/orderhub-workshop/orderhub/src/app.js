const express = require('express');
const orders = require('./orders');
const { findUser, exportReport } = require('./auth');
const app = express();
app.use(express.json());
app.get('/health', (_req, res) => res.json({ status: 'ok' }));
app.post('/orders/quote', (req, res) => {
  const { unitPricePaise, quantity } = req.body || {};
  if (!Number.isSafeInteger(unitPricePaise) || unitPricePaise < 0 || !Number.isSafeInteger(quantity) || quantity < 1) return res.status(400).json({ error: 'INVALID_ORDER' });
  res.json({ totalPaise: orders.quote(unitPricePaise, quantity) });
});
app.get('/users/:name', async (req, res) => {
  try { res.json(await findUser(req.params.name)); }
  catch (_error) { res.status(500).json({ error: 'LOOKUP_FAILED' }); }
});
app.post('/reports/export', (req, res) => {
  try { res.json({ result: exportReport(req.body && req.body.fileName) }); }
  catch (_error) { res.status(400).json({ error: 'INVALID_REPORT' }); }
});
module.exports = app;
