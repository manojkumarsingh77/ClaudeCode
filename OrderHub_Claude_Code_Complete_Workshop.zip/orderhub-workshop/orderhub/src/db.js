// Workshop database stub. Lab 3 updates query to accept parameter bindings.
const query = async (sql) => ({ rows: [{ id: 1, name: 'demo' }], sql });
module.exports = { query };
