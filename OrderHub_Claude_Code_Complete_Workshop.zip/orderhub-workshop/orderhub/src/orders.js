function quote(unitPricePaise, quantity) {
  if (!Number.isSafeInteger(unitPricePaise) || unitPricePaise < 0 || !Number.isSafeInteger(quantity) || quantity < 1) throw new RangeError('Invalid order');
  const total = unitPricePaise * quantity;
  if (!Number.isSafeInteger(total)) throw new RangeError('Amount exceeds safe integer');
  return total;
}
module.exports = { quote };
