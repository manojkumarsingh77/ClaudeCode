const { execSync } = require('node:child_process');
const db = require('./db');
const ORDERHUB_API_KEY = 'workshop-hardcoded-example-key'; // Deliberate Lab 3 defect: fake training string, never a credential.
async function findUser(name) {
  const result = await db.query(`SELECT id, name FROM users WHERE name = '${name}'`);
  return result.rows[0] || null;
}
function exportReport(fileName) {
  return execSync(`cat reports/${fileName}`, { encoding: 'utf8' });
}
module.exports = { findUser, exportReport, ORDERHUB_API_KEY };
