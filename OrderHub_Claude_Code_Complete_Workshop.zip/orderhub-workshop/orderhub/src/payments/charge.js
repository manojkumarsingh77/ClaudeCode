function charge(_card, amountPaise) {
  if (!Number.isSafeInteger(amountPaise) || amountPaise < 0) throw new RangeError('Invalid amount in paise');
  return { authorized: true, amountPaise };
}
module.exports = { charge };
