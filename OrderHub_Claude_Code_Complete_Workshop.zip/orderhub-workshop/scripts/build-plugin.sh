#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROJECT="$ROOT/orderhub"
P="$ROOT/acme-marketplace/plugins/acme-eng-toolkit"
for file in "$PROJECT/.claude/skills/release-notes/SKILL.md" "$PROJECT/.claude/agents/security-reviewer.md" "$PROJECT/mcp-servers/ticket-desk/server.mjs"; do
  if [[ ! -f "$file" ]]; then echo "Missing lab output: $file" >&2; exit 1; fi
done
mkdir -p "$P/.claude-plugin" "$P/skills" "$P/agents" "$P/mcp-servers" "$P/data"
rm -rf "$P/skills/release-notes" "$P/mcp-servers/ticket-desk"
cp -R "$PROJECT/.claude/skills/release-notes" "$P/skills/"
cp "$PROJECT/.claude/agents/security-reviewer.md" "$P/agents/"
cp -R "$PROJECT/mcp-servers/ticket-desk" "$P/mcp-servers/"
rm -rf "$P/mcp-servers/ticket-desk/node_modules"
cp "$PROJECT/data/tickets.json" "$P/data/tickets.json"
python3 - "$P/skills/release-notes/SKILL.md" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text(); s=s.replace('bash .claude/skills/release-notes/scripts/commits.sh <FROM> <TO>', 'git log --reverse --pretty=format:"%s" <FROM>..<TO>'); p.write_text(s)
PY2
cat > "$P/.claude-plugin/plugin.json" <<'JSON'
{"name":"acme-eng-toolkit","version":"1.0.0","description":"OrderHub release notes, AppSec and ticket access","author":{"name":"Acme Platform Engineering"}}
JSON
cat > "$P/.mcp.json" <<'JSON'
{"mcpServers":{"ticket-desk":{"command":"node","args":["${CLAUDE_PLUGIN_ROOT}/mcp-servers/ticket-desk/server.mjs"]}}}
JSON
echo "Plugin built at $P. Run npm install --omit=dev in $P/mcp-servers/ticket-desk"
