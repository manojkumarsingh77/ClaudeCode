#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$ROOT/orderhub/src/auth.js"
test -f "$ROOT/orderhub/data/tickets.json"
test -f "$ROOT/reference/lab2/release-notes/SKILL.md"
test -f "$ROOT/reference/lab4/server.mjs"
git -C "$ROOT/orderhub" rev-parse v1.3.0 >/dev/null
git -C "$ROOT/orderhub" log --pretty=%s v1.3.0..HEAD | grep -q 'feat(OHUB-211): add UPI payments'
node --check "$ROOT/reference/lab4/server.mjs"
node --check "$ROOT/orderhub/src/auth.js"
echo 'Starter checks passed.'
