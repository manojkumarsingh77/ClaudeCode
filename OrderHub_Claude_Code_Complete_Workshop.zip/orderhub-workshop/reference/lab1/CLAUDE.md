# OrderHub — Claude Code instructions
## Commands
- Install: `npm install`
- Test all: `npm test`
- Test one file: `npx jest tests/<file>.test.js`
## Architecture
- Express 4 service. Logic in `src/`, tests in `tests/`.
- Only `src/db.js` talks to the database.
## Conventions
- Money is integer paise. Never use floats for currency; round once at the end with Math.round.
- Every changed function needs a Jest test.
- Use CommonJS; no TypeScript.
- Use Conventional Commits with Jira key, e.g. `feat(OHUB-123): ...`.
## Guardrails
- Run `npm test` after code changes and report the result.
- Never hard-code secrets; read `process.env`.
- Ask before adding an npm dependency.
## Shared standards
@docs/coding-standards.md
