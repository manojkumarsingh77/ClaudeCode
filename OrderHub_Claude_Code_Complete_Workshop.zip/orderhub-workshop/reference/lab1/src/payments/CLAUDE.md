# Payments module rules
- NEVER log, print or persist a full PAN, CVV or expiry. Mask PAN to last four digits.
- Amounts are integer paise; reject non-integer input with HTTP 400 at route boundaries.
- PR descriptions for changes here must tag @payments-owners.
