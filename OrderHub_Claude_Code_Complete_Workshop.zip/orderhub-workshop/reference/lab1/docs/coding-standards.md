# Acme Retail coding standards
- Keep functions below 40 lines; extract helpers.
- Validate input at route boundaries.
- Use structured log context; never concatenate user input into logs.
